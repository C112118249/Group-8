import os
import json
import discord
from discord.ext import commands, tasks
import aiohttp
from io import BytesIO
from datetime import datetime, date, timedelta
from dateutil import parser as dateparser
import ssl
import certifi

try:
    from dotenv import load_dotenv
    load_dotenv()  # 載入 .env 文件
    DOTENV_LOADED = True
except ImportError:
    print("⚠️ 警告: python-dotenv 未安裝，將使用環境變數")
    DOTENV_LOADED = False
except Exception as e:
    print(f"⚠️ 警告: 載入 .env 文件時出錯: {e}")
    DOTENV_LOADED = False

def get_timezone(tz_name="Asia/Taipei"):
    """安全的時區獲取函數"""
    # 方案1: 嘗試 zoneinfo (Python 3.9+)
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(tz_name)
    except (ImportError, Exception):
        print("⚠️ zoneinfo 不可用，嘗試其他時區方案")
    
    # 方案2: 嘗試 dateutil
    try:
        from dateutil import tz as dateutil_tz
        tz_obj = dateutil_tz.gettz(tz_name)
        if tz_obj is not None:
            print("✅ 使用 dateutil 時區")
            return tz_obj
    except ImportError:
        print("⚠️ dateutil 不可用")
    
    # 方案3: 固定偏移
    from datetime import timezone
    fixed_offsets = {
        "Asia/Taipei": timedelta(hours=8),
        "Asia/Shanghai": timedelta(hours=8),
        "UTC": timedelta(hours=0),
    }
    
    if tz_name in fixed_offsets:
        print(f"✅ 使用固定偏移時區: {tz_name}")
        return timezone(fixed_offsets[tz_name])
    
    print("⚠️ 使用 UTC 作為默認時區")
    return timezone.utc

# 環境變數
TOKEN = os.getenv("GAOKE_BOT_TOKEN")
TIMEZONE = os.getenv("TIMEZONE", "Asia/Taipei")
REMINDER_CHANNEL_ID = os.getenv("REMINDER_CHANNEL_ID")

# 獲取時區對象
tz = get_timezone(TIMEZONE)

# 檢查必要的環境變數
if not TOKEN:
    print("❌ 錯誤: 未找到 GAOKE_BOT_TOKEN 環境變數")
    print("💡 請創建 .env 檔或設置環境變數")
    exit(1)

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.presences = False
bot = commands.Bot(command_prefix=commands.when_mentioned_or("!"), intents=intents)

# ========== 常量設定 ==========
MAP_PDF_URL = "https://cte.nkust.edu.tw/var/file/130/1130/img/640896759.pdf"
CALENDAR_URL = "https://acad.nkust.edu.tw/p/412-1004-1588.php?Lang=zh-tw"
EXAMS_FILE = "exams.json"

# ========== 地圖選擇按鈕 ==========
class CampusSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=30)  # 30秒後按鈕失效
        self.campus_files = {
            "建工": ["建工1.jpg", "建工2.jpg", "建工3.jpg"],
            "燕巢": ["燕巢1.jpg", "燕巢2.jpg"],
            "旗津": ["旗津1.jpg", "旗津2.jpg"],
            "第一": ["第一1.jpg", "第一2.jpg", "第一3.jpg"],
            "楠梓": ["楠梓1.jpg", "楠梓2.jpg", "楠梓3.jpg"]
        }
    
    async def send_campus_map(self, interaction: discord.Interaction, campus: str):
        """發送指定校區的地圖"""
        map_folder = "map"  # 地圖資料夾名稱
        files = []
        
        # 檢查檔案是否存在並收集
        for filename in self.campus_files.get(campus, []):
            file_path = os.path.join(map_folder, filename)
            if os.path.exists(file_path):
                files.append(discord.File(file_path, filename=filename))
            else:
                print(f"⚠️ 檔案不存在: {file_path}")
        
        if files:
            await interaction.response.send_message(
                f"🏫 **{campus}校區地圖**", 
                files=files,
                ephemeral=True  # 只有點擊按鈕的人能看到
            )
        else:
            await interaction.response.send_message(
                f"❌ 找不到{campus}校區的地圖檔案", 
                ephemeral=True
            )
    
    @discord.ui.button(label="建工", style=discord.ButtonStyle.primary, emoji="🏢")
    async def jian_gong_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "建工")
    
    @discord.ui.button(label="燕巢", style=discord.ButtonStyle.primary, emoji="🌳")
    async def yan_chao_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "燕巢")
    
    @discord.ui.button(label="旗津", style=discord.ButtonStyle.primary, emoji="🌊")
    async def qi_jin_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "旗津")
    
    @discord.ui.button(label="第一", style=discord.ButtonStyle.primary, emoji="1️⃣")
    async def di_yi_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "第一")
    
    @discord.ui.button(label="楠梓", style=discord.ButtonStyle.primary, emoji="🏫")
    async def nan_zi_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "楠梓")
    
    async def on_timeout(self):
        # 超時後禁用所有按鈕
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True

# ========== 考試系統按鈕 ==========
class ExamModal(discord.ui.Modal, title='新增考試'):
    """新增考試的模態對話框"""
    exam_title = discord.ui.TextInput(
        label='考試名稱',
        placeholder='例如: 微積分期末考',
        max_length=100
    )
    
    exam_date = discord.ui.TextInput(
        label='考試日期 (YYYY-MM-DD)',
        placeholder='例如: 2024-06-15',
        max_length=10
    )
    
    async def on_submit(self, interaction: discord.Interaction):
        # 延遲回應，我們會在後面手動回應
        await interaction.response.defer(ephemeral=True)
        
        # 驗證日期格式
        try:
            parsed_date = dateparser.parse(self.exam_date.value)
            if not parsed_date:
                await interaction.followup.send("❌ 日期格式錯誤，請使用 YYYY-MM-DD 格式", ephemeral=True)
                return
            
            date_only = parsed_date.date().isoformat()
            
            # 載入考試資料
            exams = load_exams()
            user_exams = [e for e in exams if e.get("user_id") == interaction.user.id]
            next_id = max((e.get("id", 0) for e in user_exams), default=0) + 1
            
            # 新增考試
            exams.append({
                "id": next_id,
                "date": date_only,
                "title": self.exam_title.value,
                "user_id": interaction.user.id,
                "username": str(interaction.user),
                "added_at": datetime.now().isoformat()
            })
            
            save_exams(exams)
            await interaction.followup.send(
                f"✅ 已新增考試：`{self.exam_title.value}`（{date_only}），ID={next_id}",
                ephemeral=True
            )
            
        except Exception as e:
            print(f"新增考試錯誤: {e}")
            await interaction.followup.send("❌ 新增考試時發生錯誤", ephemeral=True)

class ExamView(discord.ui.View):
    """考試管理視圖"""
    def __init__(self):
        super().__init__(timeout=60)  # 60秒後按鈕失效
    
    @discord.ui.button(label='新增考試', style=discord.ButtonStyle.primary, emoji='➕')
    async def add_exam(self, interaction: discord.Interaction, button: discord.ui.Button):
        """開啟新增考試模態對話框"""
        modal = ExamModal()
        await interaction.response.send_modal(modal)
    
    @discord.ui.button(label='查詢所有考試', style=discord.ButtonStyle.secondary, emoji='📝')
    async def list_exams(self, interaction: discord.Interaction, button: discord.ui.Button):
        """顯示用戶的所有考試"""
        exams = load_exams()
        user_exams = [e for e in exams if e.get("user_id") == interaction.user.id]
        
        if not user_exams:
            await interaction.response.send_message("📭 您目前沒有已記錄的考試", ephemeral=True)
            return
        
        # 按日期排序
        user_exams_sorted = sorted(user_exams, key=lambda e: e["date"])
        
        # 計算剩餘天數
        today = datetime.now(tz).date()
        lines = []
        for e in user_exams_sorted:
            exam_date = dateparser.parse(e["date"]).date()
            days_left = (exam_date - today).days
            status = "剩" if days_left >= 0 else "已過期"
            days_text = f"{abs(days_left)}天" if days_left != 0 else "今天"
            lines.append(f"**ID {e['id']}** • {e['title']} — {e['date']} （{status} {days_text}）")
        
        embed = discord.Embed(
            title="📚 您的考試記錄",
            description="\n".join(lines),
            color=0x3498db
        )
        embed.set_footer(text=f"共 {len(user_exams)} 筆考試記錄")
        
        await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @discord.ui.button(label='最近一場考試', style=discord.ButtonStyle.secondary, emoji='⏰')
    async def next_exam(self, interaction: discord.Interaction, button: discord.ui.Button):
        """顯示最近的一場考試"""
        exams = load_exams()
        user_exams = [e for e in exams if e.get("user_id") == interaction.user.id]
        
        if not user_exams:
            await interaction.response.send_message("📭 您目前沒有已記錄的考試", ephemeral=True)
            return
        
        # 找出未來的考試
        today = datetime.now(tz).date()
        upcoming = []
        for e in user_exams:
            exam_date = dateparser.parse(e["date"]).date()
            days_left = (exam_date - today).days
            if days_left >= 0:
                upcoming.append((e, days_left))
        
        if not upcoming:
            # 如果沒有未來的考試，顯示最近的一場已過期考試
            past_exams = []
            for e in user_exams:
                exam_date = dateparser.parse(e["date"]).date()
                days_passed = (today - exam_date).days
                past_exams.append((e, days_passed))
            
            if past_exams:
                closest_past = min(past_exams, key=lambda x: x[1])
                e, days_passed = closest_past
                await interaction.response.send_message(
                    f"📅 您最近的一場考試已過期：**{e['title']}** — {e['date']}（已過期 {days_passed} 天）",
                    ephemeral=True
                )
            else:
                await interaction.response.send_message("📭 您目前沒有已記錄的考試", ephemeral=True)
            return
        
        # 找出最近的未來考試
        closest = min(upcoming, key=lambda x: x[1])
        e, days_left = closest
        
        if days_left == 0:
            message = f"🚨 **今天考試！**\n**{e['title']}** — {e['date']}\n請做好準備！"
        elif days_left == 1:
            message = f"⚠️ **明天考試！**\n**{e['title']}** — {e['date']}\n請加緊複習！"
        else:
            message = f"⏰ 最近一場考試：\n**{e['title']}** — {e['date']}（剩 {days_left} 天）"
        
        await interaction.response.send_message(message, ephemeral=True)
    
    @discord.ui.button(label='刪除考試', style=discord.ButtonStyle.danger, emoji='🗑️')
    async def remove_exam(self, interaction: discord.Interaction, button: discord.ui.Button):
        """刪除考試的選擇界面"""
        exams = load_exams()
        user_exams = [e for e in exams if e.get("user_id") == interaction.user.id]
        
        if not user_exams:
            await interaction.response.send_message("📭 您目前沒有可刪除的考試記錄", ephemeral=True)
            return
        
        # 創建刪除視圖
        view = DeleteExamView(user_exams)
        embed = discord.Embed(
            title="🗑️ 刪除考試",
            description="請選擇要刪除的考試：",
            color=0xe74c3c
        )
        
        # 添加考試列表
        exam_list = "\n".join([f"ID {e['id']} • {e['title']} — {e['date']}" for e in user_exams])
        embed.add_field(name="您的考試", value=exam_list, inline=False)
        
        await interaction.response.send_message(embed=embed, view=view, ephemeral=True)
    
    async def on_timeout(self):
        # 超時後禁用所有按鈕
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True

class DeleteExamView(discord.ui.View):
    """刪除考試的選擇視圖"""
    def __init__(self, user_exams):
        super().__init__(timeout=30)
        self.user_exams = user_exams
        
        # 創建選擇下拉選單
        options = []
        for exam in user_exams:
            options.append(discord.SelectOption(
                label=f"ID {exam['id']}: {exam['title']}",
                description=f"日期: {exam['date']}",
                value=str(exam['id'])
            ))
        
        self.select = discord.ui.Select(
            placeholder="選擇要刪除的考試...",
            options=options,
            min_values=1,
            max_values=1
        )
        self.select.callback = self.select_callback
        self.add_item(self.select)
    
    async def select_callback(self, interaction: discord.Interaction):
        """處理選擇的考試刪除"""
        selected_id = int(self.select.values[0])
        exams = load_exams()
        
        # 找到並刪除考試
        exam_to_delete = None
        new_exams = []
        for e in exams:
            if e.get("id") == selected_id and e.get("user_id") == interaction.user.id:
                exam_to_delete = e
            else:
                new_exams.append(e)
        
        if exam_to_delete:
            save_exams(new_exams)
            await interaction.response.send_message(
                f"✅ 已刪除考試：**{exam_to_delete['title']}**（{exam_to_delete['date']}）",
                ephemeral=True
            )
        else:
            await interaction.response.send_message("❌ 找不到指定的考試", ephemeral=True)
        
        # 禁用按鈕
        for item in self.children:
            item.disabled = True
        
        # 更新訊息
        await interaction.message.edit(view=self)

# ========== 存取考試資料 ==========
def load_exams():
    if not os.path.exists(EXAMS_FILE):
        return []
    with open(EXAMS_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def save_exams(exams):
    with open(EXAMS_FILE, "w", encoding="utf-8") as f:
        json.dump(exams, f, ensure_ascii=False, indent=2)

def days_until(date_str: str) -> int:
    """計算距離指定日期的天數 - 使用全域 tz 變數"""
    dt = dateparser.parse(date_str)
    if not dt:
        return None
    
    # 確保日期有時區資訊
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=tz)
    
    dt_date = dt.date()
    today = datetime.now(tz).date()  # 使用全域 tz
    delta = (dt_date - today).days
    return delta

# ========== 幫助指令 ==========
@bot.command(name="com")
async def com_command(ctx):
    """顯示所有可用指令的幫助訊息"""
    embed = discord.Embed(
        title="🤖 高科機器人幫助指南",
        description="以下是指令列表及功能說明：",
        color=0x00ff00
    )
    
    # 基本指令
    embed.add_field(
        name="🔧 基本指令",
        value=(
            "`!test` - 測試機器人是否正常運行\n"
            "`!ping` - 顯示機器人延遲\n"
            "`!time` - 顯示當前時間\n"
            "`!com` - 顯示此幫助訊息"
        ),
        inline=False
    )
    
    # 地圖與行事曆指令
    embed.add_field(
        name="🗺️ 地圖與行事曆",
        value=(
            "`!map` - 選擇校區查看地圖\n"
            "`!calendar` - 查看教務處行事曆"
        ),
        inline=False
    )
    
    # 考試管理指令
    embed.add_field(
        name="📚 考試管理",
        value=(
            "`!exam` - 開啟個人考試管理界面\n"
            "（新增、查詢、刪除個人考試記錄）"
        ),
        inline=False
    )
    
    embed.set_footer(text="輸入 !com 可隨時查看此訊息")
    
    await ctx.send(embed=embed)

# ========== 指令：地圖與行事曆 ==========
@bot.command(name="test")
async def test_command(ctx):
    """測試機器人是否正常運行"""
    await ctx.send("🤖 機器人正常運行！")

@bot.command(name="ping")
async def ping_command(ctx):
    """顯示機器人延遲"""
    latency = round(bot.latency * 1000)
    await ctx.send(f"🏓 Pong! 延遲: {latency}ms")

@bot.command(name="time")
async def time_command(ctx):
    """顯示當前時間"""
    now = datetime.now(tz)
    await ctx.send(f"🕒 當前時間: {now.strftime('%Y-%m-%d %H:%M:%S %Z')}")

@bot.command(name="map")
async def send_map(ctx):
    """回傳高科校區地圖選擇"""
    # 檢查 map 資料夾是否存在
    map_folder = "map"
    if not os.path.exists(map_folder):
        await ctx.send("❌ 地圖資料夾不存在，請確認是否有 `map` 資料夾")
        return
    
    # 建立選擇視圖
    view = CampusSelectView()
    
    # 發送選擇訊息
    embed = discord.Embed(
        title="🏫 高科校區地圖選擇",
        description="請選擇要查看的校區地圖：",
        color=0x3498db
    )
    embed.add_field(
        name="校區說明",
        value="• 🏢 建工校區\n• 🌳 燕巢校區\n• 🌊 旗津校區\n• 1️⃣ 第一校區\n• 🏫 楠梓校區",
        inline=False
    )
    embed.set_footer(text="點擊按鈕查看對應校區地圖（30秒後按鈕失效）")
    
    await ctx.send(embed=embed, view=view)

@bot.command(name="calendar")
async def send_calendar(ctx):
    """回傳教務處行事曆"""
    reply = (
        "📅 高科教務處行事曆如下：\n"
        f"{CALENDAR_URL}"
    )
    await ctx.send(reply)

# ========== 考試管理指令 ==========
@bot.command(name="exam")
async def exam_command(ctx):
    """開啟個人考試管理界面"""
    view = ExamView()
    
    embed = discord.Embed(
        title="📚 個人考試管理系統",
        description="請選擇要執行的操作：",
        color=0x9b59b6
    )
    
    embed.add_field(
        name="功能說明",
        value=(
            "• ➕ **新增考試** - 添加新的考試記錄\n"
            "• 📝 **查詢所有考試** - 查看您的所有考試\n"
            "• ⏰ **最近一場考試** - 查看最近的考試\n"
            "• 🗑️ **刪除考試** - 刪除指定的考試記錄"
        ),
        inline=False
    )
    
    embed.set_footer(text="此界面僅您本人可見，60秒後按鈕失效")
    
    await ctx.send(embed=embed, view=view)

# ========== 自動提醒背景任務 ==========
@tasks.loop(hours=24)
async def exam_reminder_task():
    """每天檢查考試，若距離有在 notify_days 中，則發提醒到指定頻道"""
    try:
        # 使用全域 tz 變數，而不是重新創建
        now = datetime.now(tz)  # 使用全域 tz
        # 設定在每天本地時間 09:00 發送提醒
        target_hour = 9
        if now.hour != target_hour:
            return
            
        exams = load_exams()
        if not exams:
            return

        notify_days = [7, 3, 1]
        if not REMINDER_CHANNEL_ID:
            print("⚠️ REMINDER_CHANNEL_ID 未設定，跳過提醒。")
            return
            
        channel = bot.get_channel(int(REMINDER_CHANNEL_ID))
        if channel is None:
            print(f"⚠️ 找不到頻道 ID={REMINDER_CHANNEL_ID}，請確認設定是否正確。")
            return

        # 按用戶分組考試
        user_exams = {}
        for e in exams:
            user_id = e.get("user_id")
            if user_id not in user_exams:
                user_exams[user_id] = []
            user_exams[user_id].append(e)
        
        # 為每個用戶發送提醒
        for user_id, user_exam_list in user_exams.items():
            reminders = []
            for e in user_exam_list:
                d_str = e["date"]
                days = days_until(d_str)
                if days is not None and days in notify_days:
                    reminders.append(f"**{e['title']}** - {d_str}（剩 {days} 天）")
            
            if reminders:
                # 嘗試獲取用戶對象
                user = bot.get_user(user_id)
                if user:
                    try:
                        await user.send(
                            f"⏰ **考試提醒**\n" +
                            "\n".join(reminders) +
                            f"\n\n查看所有考試: 在伺服器中使用 `!exam` 命令"
                        )
                    except discord.Forbidden:
                        # 如果無法發送私訊，在頻道中提及用戶
                        if channel:
                            await channel.send(
                                f"⏰ <@{user_id}> 考試提醒：\n" +
                                "\n".join(reminders)
                            )
                
    except Exception as exc:
        print(f"exam_reminder_task error: {exc}")
        import traceback
        traceback.print_exc()

@exam_reminder_task.before_loop
async def before_reminder():
    await bot.wait_until_ready()
    print("✅ 考試提醒任務已準備就緒。")

# ========== bot 事件 ==========
@bot.event
async def on_ready():
    print(f"✅ BOT 已上線： {bot.user}（時區 {TIMEZONE}）")
    print(f"✅ 機器人ID：{bot.user.id}")
    print(f"✅ 已連接伺服器數量：{len(bot.guilds)}")
    
    for guild in bot.guilds:
        print(f"   - {guild.name} (ID: {guild.id})")
    
    if not exam_reminder_task.is_running():
        exam_reminder_task.start()

@bot.event
async def on_message(message):
    # 避免機器人回應自己的消息
    if message.author == bot.user:
        return
    
    # 調試信息：顯示收到的消息
    if message.content.startswith(('!', '！')):
        print(f"收到命令: {message.content} - 來自: {message.author} - 頻道: {message.channel}")
    
    # 繼續處理命令
    await bot.process_commands(message)

# ========== 啟動 BOT ==========
if __name__ == "__main__":
    try:
        bot.run(TOKEN)
    except discord.LoginFailure:
        print("❌ Token 錯誤，請檢查 GAOKE_BOT_TOKEN 環境變數")
    except Exception as e:
        print(f"❌ 啟動失敗: {e}")