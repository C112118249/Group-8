
import os
import json
import discord
from discord.ext import commands, tasks
import aiohttp
from io import BytesIO
from datetime import datetime, date, timedelta
from dateutil import parser as dateparser
import ssl
import certifi

try:
    from dotenv import load_dotenv
    load_dotenv()  # 載入 .env 文件
    DOTENV_LOADED = True
except ImportError:
    print("⚠️ 警告: python-dotenv 未安裝，將使用環境變數")
    DOTENV_LOADED = False
except Exception as e:
    print(f"⚠️ 警告: 載入 .env 文件時出錯: {e}")
    DOTENV_LOADED = False

def get_timezone(tz_name="Asia/Taipei"):
    """安全的時區獲取函數"""
    # 方案1: 嘗試 zoneinfo (Python 3.9+)
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(tz_name)
    except (ImportError, Exception):
        print("⚠️ zoneinfo 不可用，嘗試其他時區方案")
    
    # 方案2: 嘗試 dateutil
    try:
        from dateutil import tz as dateutil_tz
        tz_obj = dateutil_tz.gettz(tz_name)
        if tz_obj is not None:
            print("✅ 使用 dateutil 時區")
            return tz_obj
    except ImportError:
        print("⚠️ dateutil 不可用")
    
    # 方案3: 固定偏移
    from datetime import timezone
    fixed_offsets = {
        "Asia/Taipei": timedelta(hours=8),
        "Asia/Shanghai": timedelta(hours=8),
        "UTC": timedelta(hours=0),
    }
    
    if tz_name in fixed_offsets:
        print(f"✅ 使用固定偏移時區: {tz_name}")
        return timezone(fixed_offsets[tz_name])
    
    print("⚠️ 使用 UTC 作為默認時區")
    return timezone.utc

# 環境變數
TOKEN = os.getenv("GAOKE_BOT_TOKEN")
TIMEZONE = os.getenv("TIMEZONE", "Asia/Taipei")
REMINDER_CHANNEL_ID = os.getenv("REMINDER_CHANNEL_ID")

# 獲取時區對象
tz = get_timezone(TIMEZONE)

# 檢查必要的環境變數
if not TOKEN:
    print("❌ 錯誤: 未找到 GAOKE_BOT_TOKEN 環境變數")
    print("💡 請創建 .env 檔或設置環境變數")
    exit(1)

intents = discord.Intents.default()
intents.message_content = True
intents.members = True
intents.presences = False
bot = commands.Bot(command_prefix=commands.when_mentioned_or("!"), intents=intents)

# ========== 常量設定 ==========
MAP_PDF_URL = "https://cte.nkust.edu.tw/var/file/130/1130/img/640896759.pdf"
CALENDAR_URL = "https://acad.nkust.edu.tw/p/412-1004-1588.php?Lang=zh-tw"
EXAMS_FILE = "exams.json"

# ========== 存取考試資料 ==========
def load_exams():
    if not os.path.exists(EXAMS_FILE):
        return []
    with open(EXAMS_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def save_exams(exams):
    with open(EXAMS_FILE, "w", encoding="utf-8") as f:
        json.dump(exams, f, ensure_ascii=False, indent=2)

def days_until(date_str: str) -> int:
    """計算距離指定日期的天數 - 使用全域 tz 變數"""
    dt = dateparser.parse(date_str)
    if not dt:
        return None
    
    # 確保日期有時區資訊
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=tz)
    
    dt_date = dt.date()
    today = datetime.now(tz).date()  # 使用全域 tz
    delta = (dt_date - today).days
    return delta

class CampusSelectView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=30)  # 30秒後按鈕失效
        self.campus_files = {
            "建工": ["建工1.jpg", "建工2.jpg", "建工3.jpg"],
            "燕巢": ["燕巢1.jpg", "燕巢2.jpg"],
            "旗津": ["旗津1.jpg", "旗津2.jpg"],
            "第一": ["第一1.jpg", "第一2.jpg", "第一3.jpg"],
            "楠梓": ["楠梓1.jpg", "楠梓2.jpg", "楠梓3.jpg"]
        }
    
    async def send_campus_map(self, interaction: discord.Interaction, campus: str):
        """發送指定校區的地圖"""
        map_folder = "map"  # 地圖資料夾名稱
        files = []
        
        # 檢查檔案是否存在並收集
        for filename in self.campus_files.get(campus, []):
            file_path = os.path.join(map_folder, filename)
            if os.path.exists(file_path):
                files.append(discord.File(file_path, filename=filename))
            else:
                print(f"⚠️ 檔案不存在: {file_path}")
        
        if files:
            await interaction.response.send_message(
                f"🏫 **{campus}校區地圖**", 
                files=files,
                ephemeral=True  # 只有點擊按鈕的人能看到
            )
        else:
            await interaction.response.send_message(
                f"❌ 找不到{campus}校區的地圖檔案", 
                ephemeral=True
            )
    
    @discord.ui.button(label="建工", style=discord.ButtonStyle.primary, emoji="🏢")
    async def jian_gong_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "建工")
    
    @discord.ui.button(label="燕巢", style=discord.ButtonStyle.primary, emoji="🌳")
    async def yan_chao_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "燕巢")
    
    @discord.ui.button(label="旗津", style=discord.ButtonStyle.primary, emoji="🌊")
    async def qi_jin_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "旗津")
    
    @discord.ui.button(label="第一", style=discord.ButtonStyle.primary, emoji="1️⃣")
    async def di_yi_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "第一")
    
    @discord.ui.button(label="楠梓", style=discord.ButtonStyle.primary, emoji="🏫")
    async def nan_zi_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.send_campus_map(interaction, "楠梓")
    
    async def on_timeout(self):
        # 超時後禁用所有按鈕
        for item in self.children:
            if isinstance(item, discord.ui.Button):
                item.disabled = True

# ========== 指令：地圖與行事曆 ==========
@bot.command(name="test")
async def test_command(ctx):
    await ctx.send("🤖 機器人正常運行！")

@bot.command(name="ping")
async def ping_command(ctx):
    latency = round(bot.latency * 1000)
    await ctx.send(f"🏓 Pong! 延遲: {latency}ms")

@bot.command(name="time")
async def time_command(ctx):
    """顯示當前時間"""
    now = datetime.now(tz)
    await ctx.send(f"🕒 當前時間: {now.strftime('%Y-%m-%d %H:%M:%S %Z')}")

@bot.command(name="map")
async def send_map(ctx):
    """回傳高科校區地圖選擇"""
    # 檢查 map 資料夾是否存在
    map_folder = "map"
    if not os.path.exists(map_folder):
        await ctx.send("❌ 地圖資料夾不存在，請確認是否有 `map` 資料夾")
        return
    
    # 建立選擇視圖
    view = CampusSelectView()
    
    # 發送選擇訊息
    embed = discord.Embed(
        title="🏫 高科校區地圖選擇",
        description="請選擇要查看的校區地圖：",
        color=0x3498db
    )
    embed.add_field(
        name="校區說明",
        value="• 🏢 建工校區\n• 🌳 燕巢校區\n• 🌊 旗津校區\n• 1️⃣ 第一校區\n• 🏫 楠梓校區",
        inline=False
    )
    embed.set_footer(text="點擊按鈕查看對應校區地圖（30秒後按鈕失效）")
    
    await ctx.send(embed=embed, view=view)

@bot.command(name="calendar")
async def send_calendar(ctx):
    """回傳教務處行事曆"""
    reply = (
        "📅 高科教務處行事曆如下：\n"
        f"{CALENDAR_URL}"
    )
    await ctx.send(reply)

# ========== 考試管理指令 ==========
@bot.group(name="exam", invoke_without_command=True)
async def exam_group(ctx):
    await ctx.send("❓ 用法: `!exam add YYYY-MM-DD 考試名稱` / `!exam list` / `!exam next` / `!exam remove ID`")

@exam_group.command(name="add")
async def exam_add(ctx, date_str: str, *, title: str):
    try:
        parsed = dateparser.parse(date_str)
        if not parsed:
            await ctx.send("❗ 日期格式錯誤，請使用 YYYY-MM-DD。")
            return
        date_only = parsed.date().isoformat()
        exams = load_exams()
        next_id = max((e.get("id", 0) for e in exams), default=0) + 1
        exams.append({
            "id": next_id,
            "date": date_only,
            "title": title,
            "added_by": str(ctx.author),
        })
        save_exams(exams)
        await ctx.send(f"✅ 已新增考試：`{title}`（{date_only}），ID={next_id}")
    except Exception as e:
        print(f"exam_add error: {e}")
        await ctx.send("⚠️ 新增考試時發生錯誤。")

@exam_group.command(name="remove")
async def exam_remove(ctx, exam_id: int):
    exams = load_exams()
    new = [e for e in exams if e.get("id") != exam_id]
    if len(new) == len(exams):
        await ctx.send(f"❌ 找不到 ID={exam_id} 的考試。")
    else:
        save_exams(new)
        await ctx.send(f"✅ 已刪除 ID={exam_id} 的考試。")

@exam_group.command(name="list")
async def exam_list(ctx):
    exams = load_exams()
    if not exams:
        await ctx.send("目前沒有已記錄的考試。")
        return
    exams_sorted = sorted(exams, key=lambda e: e["date"])
    lines = []
    for e in exams_sorted:
        d = e["date"]
        days = days_until(d)
        if days is None:
            continue
        lines.append(f"ID {e['id']} • {e['title']} — {d} （剩 {days} 天）")
    text = "\n".join(lines)
    await ctx.send("📝 已記錄考試：\n" + text)

@exam_group.command(name="next")
async def exam_next(ctx):
    exams = load_exams()
    if not exams:
        await ctx.send("目前沒有已記錄的考試。")
        return
    upcoming = [e for e in exams if days_until(e["date"]) is not None and days_until(e["date"]) >= 0]
    if not upcoming:
        await ctx.send("沒有未來的考試（皆已過期）。")
        return
    nxt = min(upcoming, key=lambda e: dateparser.parse(e["date"]).date())
    days = days_until(nxt["date"])
    await ctx.send(f"📣 下一個考試：ID {nxt['id']} • {nxt['title']} — {nxt['date']}（剩 {days} 天）")

# ========== 自動提醒背景任務 ==========
@tasks.loop(hours=24)
async def exam_reminder_task():
    """每天檢查考試，若距離有在 notify_days 中，則發提醒到指定頻道"""
    try:
        # 使用全域 tz 變數，而不是重新創建
        now = datetime.now(tz)  # 使用全域 tz
        # 設定在每天本地時間 09:00 發送提醒
        target_hour = 9
        if now.hour != target_hour:
            return
            
        exams = load_exams()
        if not exams:
            return

        notify_days = [7, 3, 1]
        if not REMINDER_CHANNEL_ID:
            print("⚠️ REMINDER_CHANNEL_ID 未設定，跳過提醒。")
            return
            
        channel = bot.get_channel(int(REMINDER_CHANNEL_ID))
        if channel is None:
            print(f"⚠️ 找不到頻道 ID={REMINDER_CHANNEL_ID}，請確認設定是否正確。")
            return

        for e in exams:
            d_str = e["date"]
            days = days_until(d_str)
            if days is not None and days in notify_days:
                await channel.send(f"⏰ 考試提醒：**{e['title']}** 將在 {d_str}（剩 {days} 天） — ID {e['id']}")
                
    except Exception as exc:
        print(f"exam_reminder_task error: {exc}")
        import traceback
        traceback.print_exc()

@exam_reminder_task.before_loop
async def before_reminder():
    await bot.wait_until_ready()
    print("✅ 考試提醒任務已準備就緒。")

# ========== bot 事件 ==========
@bot.event
async def on_ready():
    print(f"✅ BOT 已上線： {bot.user}（時區 {TIMEZONE}）")
    print(f"✅ 機器人ID：{bot.user.id}")
    print(f"✅ 已連接伺服器數量：{len(bot.guilds)}")
    
    for guild in bot.guilds:
        print(f"   - {guild.name} (ID: {guild.id})")
    
    if not exam_reminder_task.is_running():
        exam_reminder_task.start()

@bot.event
async def on_message(message):
    # 避免機器人回應自己的消息
    if message.author == bot.user:
        return
    
    # 調試信息：顯示收到的消息
    if message.content.startswith(('!', '！')):
        print(f"收到命令: {message.content} - 來自: {message.author} - 頻道: {message.channel}")
    
    # 繼續處理命令
    await bot.process_commands(message)

# ========== 啟動 BOT ==========
if __name__ == "__main__":
    try:
        bot.run(TOKEN)
    except discord.LoginFailure:
        print("❌ Token 錯誤，請檢查 GAOKE_BOT_TOKEN 環境變數")
    except Exception as e:
        print(f"❌ 啟動失敗: {e}")
