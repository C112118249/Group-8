# bot_with_maps_calendar_exams.py

import os
import json
import discord
from discord.ext import commands, tasks
import aiohttp
from io import BytesIO
from datetime import datetime, date, timedelta
from dateutil import parser as dateparser
from zoneinfo import ZoneInfo
import ssl
import certifi

try:
    from dotenv import load_dotenv
    load_dotenv()  # 加载 .env 文件
    DOTENV_LOADED = True
except ImportError:
    print("⚠️ 警告: python-dotenv 未安装，将使用环境变量")
    DOTENV_LOADED = False
except Exception as e:
    print(f"⚠️ 警告: 加载 .env 文件时出错: {e}")
    DOTENV_LOADED = False

def get_timezone(tz_name="Asia/Taipei"):
    """安全的时区获取函数"""
    # 方案1: 尝试 zoneinfo (Python 3.9+)
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(tz_name)
    except (ImportError, Exception):
        print("⚠️ zoneinfo 不可用，尝试其他时区方案")
    
    # 方案2: 尝试 dateutil
    try:
        from dateutil import tz as dateutil_tz
        tz_obj = dateutil_tz.gettz(tz_name)
        if tz_obj is not None:
            print("✅ 使用 dateutil 时区")
            return tz_obj
    except ImportError:
        print("⚠️ dateutil 不可用")
    
    # 方案3: 固定偏移
    from datetime import timezone
    fixed_offsets = {
        "Asia/Taipei": timedelta(hours=8),
        "Asia/Shanghai": timedelta(hours=8),
        "UTC": timedelta(hours=0),
    }
    
    if tz_name in fixed_offsets:
        print(f"✅ 使用固定偏移时区: {tz_name}")
        return timezone(fixed_offsets[tz_name])
    
    print("⚠️ 使用 UTC 作为默认时区")
    return timezone.utc

# 然後你用 tz 來取得今天



# 載入 .env
load_dotenv()
TOKEN = os.getenv("GAOKE_BOT_TOKEN")
TIMEZONE = os.getenv("TIMEZONE", "Asia/Taipei")
REMINDER_CHANNEL_ID = os.getenv("REMINDER_CHANNEL_ID")  # 請設定提醒要發在哪個頻道
tz = get_timezone(TIMEZONE)
today = datetime.now(tz).date()
intents = discord.Intents.default()
intents.message_content = True
# 如果你用成員事件，就開 members
intents.members = True
# presences 若不需要就不用開
intents.presences = False
bot = commands.Bot(command_prefix=commands.when_mentioned_or("!"), intents=intents)

# ========== 常數設定 ==========
MAP_PDF_URL = "https://cte.nkust.edu.tw/var/file/130/1130/img/640896759.pdf"
CALENDAR_URL = "https://acad.nkust.edu.tw/p/412-1004-1588.php?Lang=zh-tw"
EXAMS_FILE = "exams.json"
DEFAULT_TZ = TIMEZONE

# ========== 存取考試資料 ==========

def load_exams():
    if not os.path.exists(EXAMS_FILE):
        return []
    with open(EXAMS_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def save_exams(exams):
    with open(EXAMS_FILE, "w", encoding="utf-8") as f:
        json.dump(exams, f, ensure_ascii=False, indent=2)

def days_until(date_str: str) -> int:
    # parse date_str 為 YYYY-MM-DD 或 ISO 格式
    dt = dateparser.parse(date_str)
    if not dt:
        return None
    dt_date = dt.date()
    today = datetime.now(ZoneInfo(DEFAULT_TZ)).date()
    delta = (dt_date - today).days
    return delta

# ========== 指令：地圖與行事曆 ==========
@bot.command(name="test")
async def test_command(ctx):
    await ctx.send("🤖 机器人正常运行！")

@bot.command(name="ping")
async def ping_command(ctx):
    latency = round(bot.latency * 1000)
    await ctx.send(f"🏓 Pong! 延迟: {latency}ms")

@bot.command(name="map")
async def send_map(ctx):
    """
    回傳高科校區地圖 PDF。
    """
    try:
        # 使用 certifi 证书包
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(ssl=ssl_context)
        
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.get(MAP_PDF_URL, timeout=15) as resp:
                if resp.status == 200:
                    data = await resp.read()
                    file = discord.File(BytesIO(data), filename="NKUST_map.pdf")
                    await ctx.send("📌 高科校區地圖（PDF）：", file=file)
                else:
                    await ctx.send(f"⚠️ 無法下載地圖 (HTTP {resp.status})，請使用連結：{MAP_PDF_URL}")
    except Exception as e:
        print(f"send_map error: {e}")
        # 备选方案：直接返回链接
        await ctx.send(f"📌 高科校區地圖連結：{MAP_PDF_URL}")

@bot.command(name="calendar")
async def send_calendar(ctx):
    """
    回傳教務處行事曆的網頁連結與簡要說明
    如有可能，可變成下載 PDF 上傳（但以連結為主）
    """
    reply = (
        "📅 高科教務處行事曆如下：\n"
        f"{CALENDAR_URL}\n\n"
        
    )
    await ctx.send(reply)

# ========== 考試管理指令 ==========
@bot.group(name="exam", invoke_without_command=True)
async def exam_group(ctx):
    await ctx.send("❓ 用法: `!exam add YYYY-MM-DD 考試名稱` / `!exam list` / `!exam next` / `!exam remove ID`")

@exam_group.command(name="add")
async def exam_add(ctx, date_str: str, *, title: str):
    try:
        parsed = dateparser.parse(date_str)
        if not parsed:
            await ctx.send("❗ 日期格式錯誤，請使用 YYYY-MM-DD。")
            return
        date_only = parsed.date().isoformat()
        exams = load_exams()
        next_id = max((e.get("id", 0) for e in exams), default=0) + 1
        exams.append({
            "id": next_id,
            "date": date_only,
            "title": title,
            "added_by": str(ctx.author),
        })
        save_exams(exams)
        await ctx.send(f"✅ 已新增考試：`{title}`（{date_only}），ID={next_id}")
    except Exception as e:
        print(f"exam_add error: {e}")
        await ctx.send("⚠️ 新增考試時發生錯誤。")

@exam_group.command(name="remove")
async def exam_remove(ctx, exam_id: int):
    exams = load_exams()
    new = [e for e in exams if e.get("id") != exam_id]
    if len(new) == len(exams):
        await ctx.send(f"❌ 找不到 ID={exam_id} 的考試。")
    else:
        save_exams(new)
        await ctx.send(f"✅ 已刪除 ID={exam_id} 的考試。")

@exam_group.command(name="list")
async def exam_list(ctx):
    exams = load_exams()
    if not exams:
        await ctx.send("目前沒有已記錄的考試。")
        return
    exams_sorted = sorted(exams, key=lambda e: e["date"])
    lines = []
    for e in exams_sorted:
        d = e["date"]
        days = days_until(d)
        if days is None:
            continue
        lines.append(f"ID {e['id']} • {e['title']} — {d} （剩 {days} 天）")
    text = "\n".join(lines)
    await ctx.send("📝 已記錄考試：\n" + text)

@exam_group.command(name="next")
async def exam_next(ctx):
    exams = load_exams()
    if not exams:
        await ctx.send("目前沒有已記錄的考試。")
        return
    upcoming = [e for e in exams if days_until(e["date"]) is not None and days_until(e["date"]) >= 0]
    if not upcoming:
        await ctx.send("沒有未來的考試（皆已過期）。")
        return
    nxt = min(upcoming, key=lambda e: dateparser.parse(e["date"]).date())
    days = days_until(nxt["date"])
    await ctx.send(f"📣 下一個考試：ID {nxt['id']} • {nxt['title']} — {nxt['date']}（剩 {days} 天）")

# ========== 自動提醒背景任務 ==========
@tasks.loop(hours=24)
async def exam_reminder_task():
    """
    每天檢查考試，若距離有在 notify_days 中，則發提醒到指定頻道。
    """
    try:
        tz = ZoneInfo(DEFAULT_TZ)
        now = datetime.now(tz)
        # 我們設在每天本地時間 09:00 發送提醒
        target_hour = 9
        if now.hour != target_hour:
            return
        exams = load_exams()
        if not exams:
            return

        notify_days = [7, 3, 1]
        if not REMINDER_CHANNEL_ID:
            print("⚠️ REMINDER_CHANNEL_ID 未設定，跳過提醒。")
            return
        channel = bot.get_channel(int(REMINDER_CHANNEL_ID))
        if channel is None:
            print(f"⚠️ 找不到頻道 ID={REMINDER_CHANNEL_ID}，請確認設定是否正確。")
            return

        for e in exams:
            d_str = e["date"]
            days = days_until(d_str)
            if days in notify_days:
                await channel.send(f"⏰ 考試提醒：**{e['title']}** 將在 {d_str}（剩 {days} 天） — ID {e['id']}")
    except Exception as exc:
        print(f"exam_reminder_task error: {exc}")

@exam_reminder_task.before_loop
async def before_reminder():
    await bot.wait_until_ready()
    print("✅ 考試提醒任務已準備就緒。")

# ========== bot 事件 ==========
@bot.event
async def on_ready():
    print(f"✅ BOT 已上線： {bot.user}（時區 {DEFAULT_TZ}）")
    print(f"✅ 機器人ID：{bot.user.id}")
    print(f"✅ 前綴設定：{bot.command_prefix}")
    print(f"✅ 已連接伺服器數量：{len(bot.guilds)}")
    
    # 列出所有连接的服务器
    for guild in bot.guilds:
        print(f"   - {guild.name} (ID: {guild.id})")
    
    if not exam_reminder_task.is_running():
        exam_reminder_task.start()

# ========== 此處保留你原本其他指令，例如餐點推薦、help 等 ==========

# （你原本的餐點相關功能等可以貼在這之後，不影響上面的功能）

# 最後啟動 BOT
if __name__ == "__main__":
    bot.run(TOKEN)