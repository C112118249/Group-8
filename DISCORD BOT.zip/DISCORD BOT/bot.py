import discord
import random
import json
import time
import datetime
import os
from dotenv import load_dotenv
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Button

# 載入 .env
load_dotenv()

# 檔案路徑與設定
DATA_FILE = 'currency.json'
DAILY_REWARD = 2000
HOURLY_REWARD = 400

# 遊戲狀態
games = {}

def load_data():
    try:
        with open(DATA_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_data(data):
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f, indent=4)

# 21點用
def create_deck():
    suits = ['♠️', '♥️', '♦️', '♣️']
    ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
    return [rank + suit for suit in suits for rank in ranks]

def calculate_hand(hand):
    total = 0
    num_aces = 0
    suits = ['♠️', '♥️', '♦️', '♣️']
    for card in hand:
        rank = card
        for suit in suits:
            rank = rank.replace(suit, '')
        if rank in ['J', 'Q', 'K']:
            total += 10
        elif rank == 'A':
            num_aces += 1
            total += 11
        else:
            total += int(rank)
    while total > 21 and num_aces > 0:
        total -= 10
        num_aces -= 1
    return total

# Bot 基本設定
class MyBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix='!', intents=intents)

    async def on_ready(self):
        await self.tree.sync()
        print(f'成功登入為 {self.user}')

bot = MyBot()

# --- Daily, Hourly, Balance 指令 ---
@bot.tree.command(name="daily", description="每日領取點數")
async def daily(interaction: discord.Interaction):
    userid = str(interaction.user.id)
    data = load_data()

    # 初始化使用者資料
    if userid not in data:
        data[userid] = {"balance": 0, "lastdaily": ""}  # lastdaily 用字串存日期
    current_date = datetime.datetime.utcnow().date()  # 取得 UTC 日期（日）
    last_date_str = data[userid].get("lastdaily", "")
    if last_date_str:
        last_date = datetime.datetime.strptime(last_date_str, "%Y-%m-%d").date()
    else:
        last_date = None

    # 檢查是否為新一天（日期不同）
    if last_date != current_date:
        # 可以領取獎勵
        data[userid]["balance"] += DAILY_REWARD
        data[userid]["lastdaily"] = current_date.strftime("%Y-%m-%d")  # 寫入今天日期字串
        save_data(data)
        await interaction.response.send_message(f"成功領取每日獎勵 {DAILY_REWARD} 點！目前點數：{data[userid]['balance']}")
    else:
        # 今天已領過
        await interaction.response.send_message("今日已領取過每日獎勵，請明天再來！")

@bot.tree.command(name='hourly', description='每小時領取獎勵')
async def hourly_slash(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    data = load_data()
    if user_id not in data:
        data[user_id] = {'balance': 0, 'last_daily': 0, 'last_hourly': 0}
    current_time = time.time()
    if current_time - data[user_id]['last_hourly'] >= 3600:
        data[user_id]['balance'] += HOURLY_REWARD
        data[user_id]['last_hourly'] = current_time
        save_data(data)
        await interaction.response.send_message(f"**恭喜！** 你領取了 {HOURLY_REWARD} 點每小時獎勵。你現在有 {data[user_id]['balance']} 點。")
    else:
        time_left = 3600 - (current_time - data[user_id]['last_hourly'])
        minutes = int(time_left // 60)
        seconds = int(time_left % 60)
        await interaction.response.send_message(f"你還需要等待 {minutes} 分鐘 {seconds} 秒才能再次領取每小時獎勵。")

@bot.tree.command(name='balance', description='查詢你的點數')
async def balance_slash(interaction: discord.Interaction):
    user_id = str(interaction.user.id)
    data = load_data()
    if user_id in data:
        await interaction.response.send_message(f"你現在有 {data[user_id]['balance']} 點。")
    else:
        await interaction.response.send_message("你還沒有任何點數，請輸入 /daily 或 /hourly 來領取。")

class BigSmallView(View):
    def __init__(self, userid, betamount):
        super().__init__(timeout=60)
        self.userid = userid
        self.betamount = betamount

    async def interaction_check(self, interaction: discord.Interaction):
        # 只有下注的玩家本人可以操作這個遊戲介面
        if str(interaction.user.id) != self.userid:
            await interaction.response.send_message("這不是你的遊戲！", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="大", style=discord.ButtonStyle.success)
    async def big_button(self, interaction: discord.Interaction, button: Button):
        await self.process_guess(interaction, "big")

    @discord.ui.button(label="小", style=discord.ButtonStyle.danger)
    async def small_button(self, interaction: discord.Interaction, button: Button):
        await self.process_guess(interaction, "small")

    @discord.ui.button(label="取消", style=discord.ButtonStyle.secondary)
    async def cancel_button(self, interaction: discord.Interaction, button: Button):
        await interaction.response.edit_message(content="遊戲已取消。", embed=None, view=None)
        self.stop()

    async def process_guess(self, interaction, guess):
        # 模擬出 1~10 隨機結果，6~10算大，1~5算小
        result_num = random.randint(1, 10)
        result_str = "big" if result_num > 5 else "small"
        data = load_data()

        if guess == result_str:
            # 猜對，點數增加下注額
            data[self.userid]["balance"] += self.betamount
            outcome = f"你猜對了！結果：{result_str} ({result_num})，獲得 {self.betamount} 點！"
        else:
            # 猜錯，點數扣除下注額
            data[self.userid]["balance"] -= self.betamount
            outcome = f"你猜錯了。結果：{result_str} ({result_num})，失去 {self.betamount} 點。"

        save_data(data)  # 儲存點數變化

        embed = discord.Embed(title="猜大小結果",
                              description=outcome,
                              color=discord.Color.gold())
        embed.add_field(name="目前點數", value=str(data[self.userid]["balance"]))
        # 禁用按鈕
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(embed=embed, view=self)
        self.stop()

@bot.tree.command(name="bigsmall", description="猜大小遊戲，下注點數後選擇大或小")
@app_commands.describe(amount="下注點數")
async def bigsmall(interaction: discord.Interaction, amount: int):
    userid = str(interaction.user.id)
    data = load_data()

    if userid not in data or data[userid]["balance"] < amount:
        await interaction.response.send_message("點數不足或未註冊！", ephemeral=True)
        return
    if amount <= 0:
        await interaction.response.send_message("下注點數必須大於0！", ephemeral=True)
        return

    embed = discord.Embed(title="猜大小",
                          description="點選下面按鈕選擇猜大或猜小",
                          color=discord.Color.green())

    view = BigSmallView(userid, amount)
    await interaction.response.send_message(embed=embed, view=view)

# --- 21點遊戲 View ---
class BlackjackView(discord.ui.View):
    def __init__(self, user_id, bet_amount):
        super().__init__(timeout=None)
        self.user_id = str(user_id)
        self.bet_amount = bet_amount

    async def interaction_check(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id:
            await interaction.response.send_message("你不能操作別人的遊戲！", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="加牌 (Hit)", style=discord.ButtonStyle.green)
    async def hit_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        game_state = games.get(self.user_id)
        if not game_state:
            await interaction.followup.send("遊戲已結束或不存在。")
            self.stop()
            return
        game_state['player_hand'].append(game_state['deck'].pop())
        player_score = calculate_hand(game_state['player_hand'])
        embed = discord.Embed(title="21 點遊戲", color=discord.Color.blue())
        embed.add_field(name="你的手牌", value=f"{', '.join(game_state['player_hand'])} (總點數: {player_score})", inline=False)
        embed.add_field(name="莊家的手牌", value=f"{game_state['dealer_hand'][0]}, 隱藏牌", inline=False)
        if player_score > 21:
            embed.set_footer(text="你爆牌了！")
            await interaction.message.edit(embed=embed, view=None)
            await self.end_game(interaction, is_player_bust=True)
        elif player_score == 21:
            embed.set_footer(text="你達到了 21 點！")
            await interaction.message.edit(embed=embed, view=None)
            await self.end_game(interaction)
        else:
            embed.set_footer(text="請點擊下方的按鈕來加牌或停牌。")
            await interaction.message.edit(embed=embed, view=self)

    @discord.ui.button(label="停牌 (Stand)", style=discord.ButtonStyle.red)
    async def stand_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer()
        game_state = games.get(self.user_id)
        if not game_state:
            await interaction.followup.send("遊戲已結束或不存在。")
            self.stop()
            return
        await interaction.message.edit(view=None)
        await self.end_game(interaction)

    async def end_game(self, interaction: discord.Interaction, is_player_bust=False):
        user_id = self.user_id
        game_state = games.get(user_id)
        if not game_state:
            self.stop()
            return
        data = load_data()
        player_score = calculate_hand(game_state['player_hand'])
        dealer_hand = game_state['dealer_hand']
        dealer_score = calculate_hand(dealer_hand)
        bet_amount = game_state['bet_amount']
        if user_id not in data:
            data[user_id] = {'balance': 0, 'last_daily': 0, 'last_hourly': 0}
        if is_player_bust:
            data[user_id]['balance'] -= bet_amount
            result_message = f"你爆牌了！總點數 {player_score}。\n你輸了 **{bet_amount}** 點。"
            final_color = discord.Color.red()
        else:
            await interaction.followup.send(f"你選擇停牌。莊家揭開手牌：{', '.join(dealer_hand)} (總點數: {dealer_score})")
            while dealer_score < 17:
                dealer_hand.append(game_state['deck'].pop())
                dealer_score = calculate_hand(dealer_hand)
                await interaction.followup.send(f"莊家加了一張牌。莊家的手牌：{', '.join(dealer_hand)} (總點數: {dealer_score})")
            if dealer_score > 21:
                data[user_id]['balance'] += bet_amount
                result_message = f"莊家爆牌了！總點數 {dealer_score}。\n你贏了 **{bet_amount}** 點！"
                final_color = discord.Color.green()
            elif player_score > dealer_score:
                data[user_id]['balance'] += bet_amount
                result_message = f"你的點數 {player_score} 大於莊家點數 {dealer_score}。\n你贏了 **{bet_amount}** 點！"
                final_color = discord.Color.green()
            elif player_score < dealer_score:
                data[user_id]['balance'] -= bet_amount
                result_message = f"你的點數 {player_score} 小於莊家點數 {dealer_score}。\n你輸了 **{bet_amount}** 點。"
                final_color = discord.Color.red()
            else:
                result_message = f"平手！你的點數 {player_score} 與莊家 {dealer_score} 相同。\n你的點數不變。"
                final_color = discord.Color.gold()
        save_data(data)
        if user_id in games:
            del games[user_id]
        embed = discord.Embed(title="遊戲結果", description=result_message, color=final_color)
        embed.add_field(name="你的最終點數", value=player_score, inline=True)
        embed.add_field(name="莊家的最終點數", value=dealer_score, inline=True)
        embed.set_footer(text=f"你現在有 {data[user_id]['balance']} 點。")
        await interaction.followup.send(embed=embed)
        self.stop()


# --- Blackjack Slash Command ---
@bot.tree.command(name='blackjack', description='開始一場21點遊戲')
@app_commands.describe(amount='下注金額')
async def blackjack_slash(interaction: discord.Interaction, amount: int):
    user_id = str(interaction.user.id)
    data = load_data()
    if user_id not in data or data[user_id]['balance'] < amount:
        await interaction.response.send_message("你的點數不足以進行此下注。", ephemeral=True)
        return
    if amount <= 0:
        await interaction.response.send_message("下注金額必須大於 0。", ephemeral=True)
        return
    if user_id in games:
        await interaction.response.send_message("你已經在一場21點遊戲中了！請先完成當前遊戲。", ephemeral=True)
        return
    deck = create_deck()
    random.shuffle(deck)
    player_hand = [deck.pop(), deck.pop()]
    dealer_hand = [deck.pop(), deck.pop()]
    games[user_id] = {
        'deck': deck,
        'player_hand': player_hand,
        'dealer_hand': dealer_hand,
        'bet_amount': amount,
    }
    player_score = calculate_hand(player_hand)
    dealer_score = calculate_hand([dealer_hand[0]])
    embed = discord.Embed(
        title="21 點遊戲開始！",
        description=f"你下注了 **{amount}** 點。",
        color=discord.Color.blue()
    )
    embed.add_field(name="你的手牌", value=f"{', '.join(player_hand)} (總點數: {player_score})", inline=False)
    embed.add_field(name="莊家的手牌", value=f"{dealer_hand[0]}, 隱藏牌 (總點數: {dealer_score})", inline=False)
    embed.set_footer(text="請點擊下方的按鈕來加牌或停牌。")
    view = BlackjackView(interaction.user.id, amount)
    await interaction.response.send_message(embed=embed, view=view)

#剪刀石頭布
class RPSView(View):
    def __init__(self, userid, betamount):
        super().__init__(timeout=60)
        self.userid = userid
        self.betamount = betamount
        self.result = None

    async def interaction_check(self, interaction: discord.Interaction):
        # 確保只有下注者可以點按鈕
        if str(interaction.user.id) != self.userid:
            await interaction.response.send_message("這不是你的遊戲！", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="剪刀", style=discord.ButtonStyle.primary)
    async def scissors(self, interaction: discord.Interaction, button: Button):
        await self.process_result(interaction, "剪刀")

    @discord.ui.button(label="石頭", style=discord.ButtonStyle.primary)
    async def rock(self, interaction: discord.Interaction, button: Button):
        await self.process_result(interaction, "石頭")

    @discord.ui.button(label="布", style=discord.ButtonStyle.primary)
    async def paper(self, interaction: discord.Interaction, button: Button):
        await self.process_result(interaction, "布")

    async def process_result(self, interaction, player_choice):
        bot_choice = random.choice(["剪刀", "石頭", "布"])

        # 判斷勝負
        if player_choice == bot_choice:
            outcome = "平手！點數不變。"
            change = 0
        elif (player_choice, bot_choice) in [("剪刀", "布"), ("石頭", "剪刀"), ("布", "石頭")]:
            outcome = f"你贏了！+{self.betamount}點！"
            change = self.betamount
        else:
            outcome = f"你輸了！-{self.betamount}點！"
            change = -self.betamount

        # 更新資料
        data = load_data()
        if self.userid in data:
            data[self.userid]["balance"] += change
        else:
            data[self.userid] = {"balance": change}
        save_data(data)

        embed = discord.Embed(title="剪刀石頭布結果",
                              description=f"你的選擇：{player_choice}\n機器人：{bot_choice}\n\n{outcome}\n目前點數：{data[self.userid]['balance']}",
                              color=discord.Color.blue())

        # 禁用按鈕，結束遊戲
        for child in self.children:
            child.disabled = True
        await interaction.response.edit_message(embed=embed, view=self)
        self.stop()

@bot.tree.command(name="rps", description="剪刀石頭布遊戲，下注點數並選擇你的選項")
@app_commands.describe(amount="下注點數")
async def rps(interaction: discord.Interaction, amount: int):
    userid = str(interaction.user.id)
    data = load_data()

    # 檢查點數足夠
    if userid not in data or data[userid]["balance"] < amount:
        await interaction.response.send_message("點數不足或未註冊！", ephemeral=True)
        return
    if amount <= 0:
        await interaction.response.send_message("下注必須大於0！", ephemeral=True)
        return

    embed = discord.Embed(title="剪刀石頭布",
                          description="請按下方按鈕選擇你的出拳",
                          color=discord.Color.green())
    view = RPSView(userid, amount)
    await interaction.response.send_message(embed=embed, view=view)

# --- Bot run ---
TOKEN = os.getenv('DISCORD_TOKEN')
if not TOKEN:
    print("找不到 DISCORD_TOKEN，請確認 .env 檔案存在並填好 Token")
else:
    bot.run(TOKEN)