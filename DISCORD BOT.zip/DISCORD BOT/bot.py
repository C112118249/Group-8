import discord
from discord.ext import commands
import os
from dotenv import load_dotenv

# 載入環境變數
load_dotenv()
TOKEN = os.getenv("GAOKE_BOT_TOKEN")

# 設定 Intents
intents = discord.Intents.default()
intents.message_content = True  # 允許讀取訊息內容，才能觸發指令

# 建立 Bot 實例
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"✅ 高科BOT 已上線：{bot.user}")

@bot.command()
async def ping(ctx):
    await ctx.send("高科BOT 回覆：Pong!")

@bot.command()
async def 晚餐(ctx):
    await ctx.send("高科BOT 推薦你今晚吃：火鍋 🍲")

bot.run(TOKEN)
