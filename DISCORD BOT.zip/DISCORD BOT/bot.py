import discord
from discord.ext import commands
import os
import random
import googlemaps
from dotenv import load_dotenv
from geopy.distance import geodesic  # 計算距離

# 載入 .env
load_dotenv()
TOKEN = os.getenv("GAOKE_BOT_TOKEN")
GOOGLE_KEY = os.getenv("GOOGLE_MAPS_API_KEY")

# Google Maps Client
gmaps = googlemaps.Client(key=GOOGLE_KEY)

# 設定 intents
intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"✅ 高科BOT 已上線：{bot.user}")

# --- Ping 測試 ---
@bot.command()
async def ping(ctx):
    await ctx.send("正在線上，需要什麼服務嗎?")

# --- 餐點推薦 ---
def translate_price_level(price_level):
    """把 Google price_level 轉換成中文描述"""
    mapping = {
        0: "免費 🆓",
        1: "平價 💰",
        2: "中等 💵",
        3: "稍貴 💎",
        4: "高價 👑"
    }
    return mapping.get(price_level, "無資料")

@bot.command(name="餐點推薦")
async def dinner_recommend(ctx, address_arg="N", radius_arg="N", keyword_arg="N", min_price_arg="N", max_price_arg="N"):
    try:
        # 預設值
        default_location = (22.757903650773226, 120.3415953004765)  # 高科第一校區
        address = None if address_arg == "N" else address_arg
        radius = 3000 if radius_arg == "N" else int(radius_arg)
        keyword = None if keyword_arg == "N" else keyword_arg
        min_price = None if min_price_arg == "N" else int(min_price_arg)
        max_price = None if max_price_arg == "N" else int(max_price_arg)

        # 範圍檢查
        if radius < 500 or radius > 10000:
            await ctx.send("⚠️ 距離必須在 500 ~ 10000 公尺之間。")
            return

        # 地址轉換
        if address:
            geocode = gmaps.geocode(address)
            if not geocode:
                await ctx.send(f"❌ 找不到地址：{address}")
                return
            location = (
                geocode[0]["geometry"]["location"]["lat"],
                geocode[0]["geometry"]["location"]["lng"]
            )
        else:
            location = default_location

        # 搜尋餐廳
        places = gmaps.places_nearby(
            location=f"{location[0]},{location[1]}",
            radius=radius,
            type="restaurant",
            keyword=keyword,
            min_price=min_price,
            max_price=max_price
        )

        # 篩選 4⭐ 以上
        good_places = [p for p in places["results"] if p.get("rating", 0) >= 4.0]

        if not good_places:
            await ctx.send(f"😢 {radius/1000:.1f} 公里內沒有符合條件的餐廳。")
            return

        # 隨機選三間
        recommendations = random.sample(good_places, min(6, len(good_places)))
        reply = f"🍽️ 高科BOT 餐點推薦（{radius/1000:.1f} 公里內"
        reply += f"｜類型：{keyword}" if keyword else ""
        reply += f"｜價格：{min_price}~{max_price}" if min_price is not None else ""
        reply += f"｜起點：{address if address else '預設座標'}）：\n\n"
        for r in recommendations:
            name = r["name"]
            rating = r.get("rating", "無評分")
            addr = r.get("vicinity", "地址未知")
            price_text = translate_price_level(r.get("price_level"))
            place_id = r.get("place_id")
            maps_url = f"https://www.google.com/maps/place/?q=place_id:{place_id}"
            reply += f"➡️ {name} - ⭐ {rating}｜{price_text}\n📍 {addr}\n🔗 [Google地圖]({maps_url})\n\n"

        await ctx.send(reply)

    except Exception as e:
        await ctx.send("⚠️ 發生錯誤，請檢查輸入或 API Key。")
        print(e)




@bot.command(name="指令")
async def help_commands(ctx):
    embed = discord.Embed(
        title="📖 高科BOT 指令教學",
        description="以下是目前支援的指令與用法：",
        color=discord.Color.green()
    )

    embed.add_field(
        name="1️⃣ !ping",
        value="測試 BOT 是否在線\n範例：`!ping`",
        inline=False
    )

    embed.add_field(
        name="2️⃣ !餐點推薦 [地址] [距離] [關鍵字] [最低價格] [最高價格]",
        value=(
            "推薦餐廳 (限 4⭐ 以上)\n\n"
            "**參數說明 (可用 `N` 代表預設值)：**\n"
            "• 地址 → 起點位置（例如：高雄車站）\n"
            "　輸入 `N` → 使用預設（高科第一校區）\n"
            "• 距離 → 搜尋範圍（500 ~ 10000 公尺）\n"
            "　輸入 `N` → 預設 3000 公尺\n"
            "• 關鍵字 → 限定餐廳類型（火鍋、拉麵、咖啡…）\n"
            "　輸入 `N` → 不限制\n"
            "• 最低價格 / 最高價格 → 限定價格等級 (0~4)\n"
            "　輸入 `N` → 不限制\n\n"
            "**價格等級對照：**\n"
            "0 = 免費 🆓\n"
            "1 = 平價 💰\n"
            "2 = 中等 💵\n"
            "3 = 稍貴 💎\n"
            "4 = 高價 👑\n\n"
            "**範例：**\n"
            "• `!餐點推薦` → 預設起點 + 預設距離 (3 公里)\n"
            "• `!餐點推薦 N 5000 火鍋` → 預設起點，5 公里內火鍋\n"
            "• `!餐點推薦 高雄車站 N 咖啡 1 2` → 高雄車站，3 公里內咖啡廳，價格 1~2\n"
            "• `!餐點推薦 N N 拉麵` → 預設起點 + 預設距離，找拉麵"
        ),
        inline=False
    )

    embed.add_field(
        name="3️⃣ !指令",
        value="顯示所有指令的說明",
        inline=False
    )

    embed.set_footer(text="高科BOT — 餐點推薦好幫手 🍽️")

    await ctx.send(embed=embed)



bot.run(TOKEN)
