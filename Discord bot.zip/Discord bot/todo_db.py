# todo_db.py
import sqlite3
import os

DB_PATH = "todos.db"  # 資料庫檔案名稱


def get_conn():
    """取得一個連線，並設定 row_factory 可以用欄位名稱取值。"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """初始化資料庫，若表格不存在就建立。"""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS todos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            meeting TEXT NOT NULL,
            content TEXT NOT NULL,
            deadline TEXT,
            created_by TEXT,
            done INTEGER NOT NULL DEFAULT 0
        );
        """
    )
    conn.commit()
    conn.close()


def add_todo(guild_id: int, meeting: str, content: str,
             deadline: str, created_by: str):
    """
    新增代辦事項。
    若同一個伺服器，已經有「同會議 + 同內容 + 同截止日」且未完成的，就不再新增，
    而是回傳那一筆的 id。
    回傳：(task_id, created)
        - created = True  → 真的有新增
        - created = False → 已經存在，沒有再插入
    """
    conn = get_conn()
    cur = conn.cursor()

    # 1️⃣ 先查：這個伺服器裡，有沒有「同會議 + 同內容」且尚未完成的代辦
    cur.execute("""
        SELECT id, done, deadline
        FROM todos
        WHERE guild_id = ?
          AND meeting  = ?
          AND content  = ?
          AND done = 0
    """, (guild_id, meeting, content))

    row = cur.fetchone()
    if row:
        # 已經存在一筆一樣的未完成代辦
        task_id = row["id"]
        conn.close()
        return task_id, False

    # 2. 如果沒有，就真的新增一筆
    cur.execute("""
        INSERT INTO todos (guild_id, meeting, content, deadline, created_by, done)
        VALUES (?, ?, ?, ?, ?, 0)
    """, (guild_id, meeting, content, deadline, created_by))

    conn.commit()
    task_id = cur.lastrowid
    conn.close()
    return task_id, True


def list_todos(guild_id: int):
    """取得某個伺服器的全部代辦事項（依 id 排序）。"""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT id, meeting, content, deadline, created_by, done
        FROM todos
        WHERE guild_id = ?
        ORDER BY id ASC
        """,
        (guild_id,),
    )
    rows = cur.fetchall()
    conn.close()
    return rows


def toggle_todo_done(guild_id: int, task_id: int):
    """
    切換某個代辦的完成狀態：
    - 如果原本是 0 → 改成 1
    - 原本是 1 → 改成 0
    回傳更新後的那一筆資料（或 None 如果找不到）。
    """
    conn = get_conn()
    cur = conn.cursor()
    # 先查原本的紀錄
    cur.execute(
        "SELECT id, meeting, content, deadline, created_by, done FROM todos WHERE guild_id = ? AND id = ?",
        (guild_id, task_id),
    )
    row = cur.fetchone()
    if not row:
        conn.close()
        return None

    new_done = 0 if row["done"] == 1 else 1
    cur.execute(
        "UPDATE todos SET done = ? WHERE id = ?",
        (new_done, task_id),
    )
    conn.commit()

    # 重新抓一次更新後的資料
    cur.execute(
        "SELECT id, meeting, content, deadline, created_by, done FROM todos WHERE id = ?",
        (task_id,),
    )
    updated = cur.fetchone()
    conn.close()
    return updated





# 取得某伺服器所有「有代辦的會議名稱」（不重複）
def list_meetings(guild_id: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "SELECT DISTINCT meeting FROM todos WHERE guild_id = ? ORDER BY meeting",
        (guild_id,),
    )
    meetings = [row[0] for row in cur.fetchall()]
    conn.close()
    return meetings


# 取得「指定會議」底下的所有代辦
def list_todos_by_meeting(guild_id: int, meeting: str):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT id, meeting, content, deadline, created_by, done
        FROM todos
        WHERE guild_id = ? AND meeting = ?
        ORDER BY id
        """,
        (guild_id, meeting),
    )

    cols = [c[0] for c in cur.description]
    rows = [dict(zip(cols, r)) for r in cur.fetchall()]
    conn.close()
    return rows


# 刪除一筆代辦
def delete_todo(guild_id: int, task_id: int) -> bool:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "DELETE FROM todos WHERE guild_id = ? AND id = ?",
        (guild_id, task_id),
    )
    deleted = cur.rowcount
    conn.commit()
    conn.close()
    return deleted > 0
