# speech.py
"""
負責：
1. 建立 Whisper 模型（GPU/CPU）
2. 把 sink.audio_data 存成 .wav 檔
3. 用多執行緒 + asyncio 並行轉錄
4. 回傳每個使用者的文字 transcripts 以及組合好的 block 字串
"""

import os
import asyncio
from concurrent.futures import ThreadPoolExecutor
from faster_whisper import WhisperModel

from config import (
    WHISPER_MODEL,
    WHISPER_DEVICE,
    WHISPER_COMPUTE_TYPE,
    MAX_WORKERS,
    RECORDINGS_DIR,
)


# --------------------------------------------------
# 建立 Whisper 模型（有 GPU 就用 GPU，失敗改用 CPU）
# --------------------------------------------------
def _create_model():
    try:
        print(f"[Whisper] 嘗試使用 {WHISPER_DEVICE} / {WHISPER_COMPUTE_TYPE}")
        return WhisperModel(
            WHISPER_MODEL,
            device=WHISPER_DEVICE,
            compute_type=WHISPER_COMPUTE_TYPE,
        )
    except Exception as e:
        print(f"[Whisper] 使用 GPU 失敗，改用 CPU int8，錯誤：{e}")
        return WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8")


model = _create_model()

# GPU/CPU 並行轉錄用的執行緒池
executor = ThreadPoolExecutor(max_workers=MAX_WORKERS)


# --------------------------------------------------
# 單一音檔的「非同步轉錄」封裝
# --------------------------------------------------
async def transcribe_file(path: str):
    """
    把同步的 model.transcribe 包成 async，避免卡住整個 bot。
    回傳 (segments, info)
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        executor,
        lambda: model.transcribe(
            path,
            language="zh",
            beam_size=5,
            vad_filter=True,
        ),
    )


# --------------------------------------------------
# 主要 API：處理整個 sink，回傳 transcripts & block
# --------------------------------------------------
async def save_and_transcribe_all(sink, ctx):
    """
    處理錄音完的 sink：
    1. 檢查有沒有聲音
    2. 每個使用者各存一個 wav 檔
    3. 並行轉錄全部 wav
    4. 組成 transcripts dict & block 文字
    """

    # 1. 沒錄到任何聲音
    if not sink.audio_data:
        await ctx.send("❌ 沒有錄到任何聲音。")
        return None, None

    os.makedirs(RECORDINGS_DIR, exist_ok=True)

    audio_paths = {}  # user_id -> filepath
    usernames = {}    # user_id -> username

    # 2. 儲存每個使用者的音檔
    for user_id, audio in sink.audio_data.items():
        user = ctx.guild.get_member(user_id)
        username = user.name if user else f"user_{user_id}"

        filepath = os.path.join(RECORDINGS_DIR, f"{ctx.guild.id}_{user_id}.wav")
        with open(filepath, "wb") as f:
            f.write(audio.file.getvalue())

        audio_paths[user_id] = filepath
        usernames[user_id] = username

    await ctx.send(f"🎧 偵測到 {len(audio_paths)} 份語音，正在並行轉錄…")

    # 3. 並行跑所有音檔
    tasks = [transcribe_file(p) for p in audio_paths.values()]
    results = await asyncio.gather(*tasks)

    transcripts = {}
    user_ids = list(audio_paths.keys())

    # 4. 整理結果
    for i, (segments, info) in enumerate(results):
        user_id = user_ids[i]
        username = usernames[user_id]

        text = " ".join(seg.text for seg in segments).strip()
        if not text:
            text = "(無語音內容)"

        transcripts[username] = text

        # 如果你想保留音檔，就把下面這段註解掉
        try:
            os.remove(audio_paths[user_id])
        except Exception:
            pass

    # 把所有人的發言組成一大段文字，給 Gemini 用
    block = "\n\n".join([f"\n{t}" for u, t in transcripts.items()])

    return transcripts, block
