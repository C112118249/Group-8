# speech.py
import os
import asyncio
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

import discord
from faster_whisper import WhisperModel

# Whisper 模型（跟你原本設定一樣）
model = WhisperModel("large-v3-turbo", device="cuda", compute_type="float16")

# GPU 並行運算池
executor = ThreadPoolExecutor(max_workers=6)


async def transcribe_async(path: str):
    """非同步包裝 Whisper 推論（讓它配合 asyncio 使用）"""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        executor,
        lambda: model.transcribe(
            path,
            language="zh",
            beam_size=5,
            vad_filter=True,
        )
    )


async def process_sink_and_save_txt(sink, ctx):
    """
    處理 Discord 錄音 sink：
    1. 把每個使用者的語音存成 wav
    2. Whisper 幫全部檔案轉文字
    3. 把所有人的文字組成一個 txt 檔，上傳到 Discord
    4. 回傳 full_text（給 Gemini 用）
    """

    # 1. 完全沒錄到東西
    if not sink.audio_data:
        await ctx.send("❌ 沒有錄到任何聲音。")
        return None, None

    os.makedirs("recordings", exist_ok=True)

    audio_paths = {}   # user_id → wav 檔路徑
    usernames = {}     # user_id → 使用者名稱

    # 2. 儲存音檔
    for user_id, audio in sink.audio_data.items():
        user = ctx.guild.get_member(user_id)
        username = user.name if user else f"user_{user_id}"

        filepath = f"recordings/{ctx.guild.id}_{user_id}.wav"
        with open(filepath, "wb") as f:
            f.write(audio.file.getvalue())

        audio_paths[user_id] = filepath
        usernames[user_id] = username

    await ctx.send(f"🎧 偵測到 {len(audio_paths)} 份語音，正在使用 GPU 並行辨識…")

    # 3. 開始同時轉錄所有音檔
    tasks = [transcribe_async(p) for p in audio_paths.values()]
    results = await asyncio.gather(*tasks)

    transcripts = {}
    user_ids = list(audio_paths.keys())

    # 4. 把結果對回使用者 & 移除 wav
    for i, (segments, info) in enumerate(results):
        user_id = user_ids[i]
        username = usernames[user_id]

        text = " ".join(seg.text for seg in segments).strip()
        if not text:
            text = "(無語音內容)"

        transcripts[username] = text

        # 如果你想保留 wav，就把這個刪檔區塊註解掉
        try:
            os.remove(audio_paths[user_id])
        except:
            pass

    # 5. 把全部辨識結果組成一個大字串
    full_text = ""
    for u, t in transcripts.items():
        full_text += f"\n{t}\n\n"

    # 6. 寫成 txt 檔
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    txt_path = os.path.join("recordings", f"transcript_{ctx.guild.id}_{ts}.txt")

    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(full_text)

    # 7. 上傳檔案到 Discord 給你檢查辨識內容
    await ctx.send(
        "📄 已產生完整辨識文字檔案（txt），可下載查看每個人的語音轉文字：",
        file=discord.File(txt_path)
    )

    # 把 full_text 和 檔案路徑回傳給 bot.py
    return full_text, txt_path
