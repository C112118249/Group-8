# config.py
import os
from dotenv import load_dotenv

# 讀取 .env
load_dotenv()

# ---- Discord / Gemini ----
BOT_TOKEN = os.getenv("BOT_TOKEN")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# ---- Whisper 設定 ----
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "large-v3-turbo")
WHISPER_DEVICE = os.getenv("WHISPER_DEVICE", "cuda")         # "cuda" or "cpu"
WHISPER_COMPUTE_TYPE = os.getenv("WHISPER_COMPUTE_TYPE", "float16")
MAX_WORKERS = int(os.getenv("MAX_WORKERS", "6"))

# ---- 檔案路徑 ----
RECORDINGS_DIR = os.getenv("RECORDINGS_DIR", "recordings")

# ---- Gemini 模型名稱 ----
GEMINI_MODEL_FLASH = os.getenv("GEMINI_MODEL_FLASH", "models/gemini-2.5-flash")
GEMINI_MODEL_PRO = os.getenv("GEMINI_MODEL_PRO", "models/gemini-2.5-pro")
