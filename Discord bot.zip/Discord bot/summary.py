# summary.py
"""
負責：
1. 設定 Gemini API
2. 選擇要用的 Gemini 模型
3. 把會議整段文字丟給 Gemini，產生摘要
"""

import asyncio
import google.generativeai as genai

from config import (
    GEMINI_API_KEY,
    GEMINI_MODEL_FLASH,
    GEMINI_MODEL_PRO,
)

# 初始化 Gemini
genai.configure(api_key=GEMINI_API_KEY)


def get_gemini_model():
    """優先使用 Flash，失敗再改用 Pro。"""
    try:
        return genai.GenerativeModel(GEMINI_MODEL_FLASH)
    except Exception:
        print("⚠️ 使用 Flash 模型失敗，改用 Pro")
        return genai.GenerativeModel(GEMINI_MODEL_PRO)


async def summarize_meeting(block: str) -> str:
    """把所有會議文字 block 丟給 Gemini，回傳摘要文字。"""
    if not block.strip():
        return "（沒有任何可整理的會議內容）"

    prompt = f"""
你是一個會從語音辨識內容中整理會議紀錄的助理。
辨識內容可能有錯字或口語化，請用語意理解。

請你輸出：

1️⃣ 會議整體主題（1~2 句）
2️⃣ 會議重點摘要（3～8 點，條列式）
3️⃣ 若有共識、決策或待辦事項，請用「待辦列表」列出

以下是所有使用者的發言內容：
---
{block}
"""

    model = get_gemini_model()

    try:
        # 用 asyncio.to_thread 避免阻塞整個 event loop
        resp = await asyncio.to_thread(model.generate_content, prompt)
        return resp.text.strip()
    except Exception as e:
        return f"❌ Gemini 整理失敗：{e}"
