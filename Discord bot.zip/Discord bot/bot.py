import discord
from discord.ext import commands
import os
from dotenv import load_dotenv
import wave
from faster_whisper import WhisperModel
import google.generativeai as genai
load_dotenv()
TOKEN = os.getenv('BOT_TOKEN')
if TOKEN is None:
    print("錯誤：請設定 'BOT_TOKEN' 環境變數。")
    exit()

intents = discord.Intents.default()
intents.message_content = True
intents.voice_states = True
intents.guilds = True

bot = commands.Bot(command_prefix='!', intents=intents)

# 儲存每伺服器的 sink
sink_dict = {}
model = WhisperModel("medium", device="cpu", compute_type="int8")
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))


def get_gemini_model():
    """優先使用 Flash，失敗則自動升級到 Pro。"""
    try:
        return genai.GenerativeModel("models/gemini-2.5-flash")
    except Exception:
        print("⚠️ Flash  無法使用，改用 2.5pro 模型")
        return genai.GenerativeModel("models/gemini-2.5-pro")


async def finished_callback(sink, ctx):
    if not sink.audio_data:
        await ctx.send("沒有錄到任何聲音。")
        return

    # 建立錄音資料夾
    if not os.path.exists("recordings"):
        os.makedirs("recordings")

    # 逐一處理每位使用者錄音
    for user_id, audio in sink.audio_data.items():
        user = ctx.guild.get_member(user_id)
        username = user.name if user else f"user_{user_id}"
        path = f"recordings/{ctx.guild.id}_{username}.wav"

        # 儲存音檔
        with open(path, "wb") as f:
            f.write(audio.file.getvalue())

        await ctx.send(f"🎧 正在辨識 **{username}** 的語音...")

        # 進行語音辨識
        segments, info = model.transcribe(path, beam_size=5, language="zh")
        text = " ".join([segment.text for segment in segments])

        if not text.strip():
            await ctx.send(f"（{username}）未偵測到語音內容。")
            continue

        await ctx.send(f"📝 **{username}** 的語音轉文字：\n{text[:500]}")

        # ===== 用 Gemini 生成摘要 =====
        prompt = f"""
        以下是從語音辨識轉出的文字，可能有些錯字或口語化。
        請根據語意整理出：
        1️⃣ 說話的主題
        2️⃣ 3~5 個重點摘要
        3️⃣ 若有待辦或行動項目請列出。
        ---
        語音內容如下：
        {text}
        """

        try:
            gemini_model = get_gemini_model()
            response = gemini_model.generate_content(prompt)
            summary = response.text.strip()
        except Exception as e:
            summary = f"❌ Gemini 摘要失敗：{e}"

        await ctx.send(f"💡 **{username}** 的語音摘要：\n{summary}")

    await ctx.send("✅ 所有錄音皆已辨識並摘要完成。")

@bot.event
async def on_ready():
    print(f'Logged in as: {bot.user.name} (ID: {bot.user.id})')
    print(f'已加入 {len(bot.guilds)} 個伺服器。')

@bot.command(name='join', help='讓機器人加入你所在的語音頻道')
async def join(ctx):
    if ctx.author.voice and ctx.author.voice.channel:
        channel = ctx.author.voice.channel
        if ctx.voice_client:
            await ctx.voice_client.move_to(channel)
        else:
            await channel.connect()
        await ctx.send(f'已加入頻道：{channel.name}')
    else:
        await ctx.send('你必須先進入一個語音頻道，我才知道要去哪裡！')

@bot.command(name='leave', help='讓機器人離開語音頻道')
async def leave(ctx):
    vc = ctx.voice_client
    if vc:
        if ctx.guild.id in sink_dict:
            vc.stop_recording()
            del sink_dict[ctx.guild.id]
        await vc.disconnect()
        await ctx.send('已離開語音頻道。')
    else:
        await ctx.send('我現在不在任何語音頻道中。')

@bot.command(name='listen', help='開始錄製語音頻道中的聲音')
async def listen(ctx):
    vc = ctx.voice_client
    if not vc:
        return await ctx.send("我不在語音頻道中。請先用 `!join`。")
    if ctx.guild.id in sink_dict:
        return await ctx.send("我已經在錄音了！")

    sink = discord.sinks.WaveSink()
    sink_dict[ctx.guild.id] = sink

    vc.start_recording(sink, finished_callback, ctx)
    await ctx.send("開始錄音！")

@bot.command(name='stop', help='停止錄音並儲存檔案')
async def stop(ctx):
    vc = ctx.voice_client
    if not vc or ctx.guild.id not in sink_dict:
        return await ctx.send("我目前沒有在錄音。")
    vc.stop_recording()
    del sink_dict[ctx.guild.id]
    await ctx.send("錄音停止，正在處理音檔...")

try:
    bot.run(TOKEN)
except discord.errors.LoginFailure:
    print("登入失敗：請檢查 BOT_TOKEN。")
except discord.errors.PrivilegedIntentsRequired:
    print("權限錯誤：請確認已啟用必要的 Intents。")
