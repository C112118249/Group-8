# bot.py
import discord
from discord.ext import commands

from config import BOT_TOKEN
from speech import save_and_transcribe_all
from summary import summarize_meeting

# ======================================================
#                   Discord 基本設定
# ======================================================
intents = discord.Intents.default()
intents.message_content = True   # 讀取文字訊息（!指令）
intents.voice_states = True      # 語音頻道狀態（錄音用）
intents.guilds = True            # 伺服器 / 成員資訊

bot = commands.Bot(command_prefix="!", intents=intents)

# 記錄每個伺服器目前的錄音 sink
sink_dict = {}


# ======================================================
#        錄音完成後，Discord 會呼叫的 callback
# ======================================================
async def finished_callback(sink, ctx):
    # 交給 speech.py 處理錄音檔 + Whisper 轉錄
    transcripts, block = await save_and_transcribe_all(sink, ctx)

    if not transcripts:
        # 沒錄到東西或失敗已在裡面處理
        return

    await ctx.send("📝 Whisper 完成，正在使用 Gemini 產生會議摘要…")

    # 交給 summary.py 和 Gemini 溝通
    summary_text = await summarize_meeting(block)

    await ctx.send(f"💡 **AI 會議總結：**\n{summary_text}")
    await ctx.send("✅ 全部處理完成！")


# ======================================================
#                     事件 & 指令
# ======================================================
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"已加入 {len(bot.guilds)} 個伺服器。")


@bot.command(name="join", aliases=["加入頻道"])
async def join(ctx):
    """讓 Bot 加入你所在的語音頻道"""
    if ctx.author.voice and ctx.author.voice.channel:
        channel = ctx.author.voice.channel
        if ctx.voice_client:
            await ctx.voice_client.move_to(channel)
        else:
            await channel.connect()
        await ctx.send(f"已加入語音頻道：{channel.name}")
    else:
        await ctx.send("❌ 你必須先進入語音頻道。")


@bot.command(name="leave", aliases=["離開頻道"])
async def leave(ctx):
    """讓 Bot 離開語音頻道"""
    vc = ctx.voice_client
    if vc:
        if ctx.guild.id in sink_dict:
            vc.stop_recording()
            del sink_dict[ctx.guild.id]
        await vc.disconnect()
        await ctx.send("👋 已離開語音頻道。")
    else:
        await ctx.send("我目前不在任何語音頻道內。")


@bot.command(name="record", aliases=["開始錄音"])
async def record(ctx):
    """開始錄製語音頻道中的聲音"""
    vc = ctx.voice_client
    if not vc:
        return await ctx.send("❌ 我不在語音頻道中，請先用 `!加入頻道`。")

    if ctx.guild.id in sink_dict:
        return await ctx.send("❌ 我已經在錄音了。")

    sink = discord.sinks.WaveSink()
    sink_dict[ctx.guild.id] = sink

    vc.start_recording(sink, finished_callback, ctx)
    await ctx.send("🎙 開始錄音！")


@bot.command(name="stop", aliases=["停止錄音"])
async def stop(ctx):
    """停止錄音並觸發 Whisper + Gemini 流程"""
    vc = ctx.voice_client
    if not vc or ctx.guild.id not in sink_dict:
        return await ctx.send("❌ 目前沒有在錄音。")

    vc.stop_recording()
    del sink_dict[ctx.guild.id]
    await ctx.send("⏹ 錄音停止，稍後會產生會議摘要…")


# ======================================================
#                     啟動 Bot
# ======================================================
if not BOT_TOKEN:
    print("錯誤：請在 .env 設定 BOT_TOKEN")
else:
    bot.run(BOT_TOKEN)
