# bot.py
import discord
from discord.ext import commands
from todo_db import (
    add_todo, 
    list_todos, 
    toggle_todo_done,  
    init_db,
    list_meetings,
    list_todos_by_meeting,
    delete_todo,
)
from datetime import datetime
from config import BOT_TOKEN
from summary import summarize_meeting
from speech import process_sink_and_save_txt


# ======================================================
#                   Discord 基本設定
# ======================================================
intents = discord.Intents.default()
intents.message_content = True   # 讀取文字訊息（!指令）
intents.voice_states = True      # 語音頻道狀態（錄音用）
intents.guilds = True            # 伺服器 / 成員資訊

bot = commands.Bot(command_prefix="!", intents=intents)

# 記錄每個伺服器目前的錄音 sink
sink_dict = {}


# ======================================================
#        錄音完成後，Discord 會呼叫的 callback
# ======================================================
async def finished_callback(sink, ctx):
    """
    Discord 錄音結束後，會自動被呼叫：
      1. 呼叫 speech.process_sink_and_save_txt 做轉錄 + 存 txt + 上傳檔案
      2. 拿到 full_text 後，呼叫 summary.summarize_meeting 做 AI 摘要
      3. 把最後的會議總結貼回頻道
    """

    # 1 先讓 speech 處理錄音 + 產出 txt 檔
    full_text, txt_path = await process_sink_and_save_txt(sink, ctx)

    # 如果前面就失敗（例如沒聲音），full_text 會是 None
    if not full_text:
        return

    # 2 呼叫 Gemini 產生摘要
    await ctx.send("📝 Whisper 完成，正在使用 Gemini 整理摘要…")

    try:
        summary_text = await summarize_meeting(full_text)
    except Exception as e:
        summary_text = f"❌ Gemini 整理失敗：{e}"

    # 3 把摘要貼回 Discord
    await ctx.send(f"💡 **AI 會議總結**：\n{summary_text}")
    await ctx.send("✅ 全部完成！")








class MeetingTodoView(discord.ui.View):
    """一個會議一頁的代辦清單 View，可以切換會議、按鈕刪除代辦"""

    def __init__(self, guild_id: int, user_id: int):
        super().__init__(timeout=300)  # 5 分鐘沒動作就失效
        self.guild_id = guild_id
        self.user_id = user_id

        self.meetings = list_meetings(guild_id)  # 所有有代辦的會議名稱
        self.index = 0  # 目前顯示第幾個會議
        self.build_buttons()

    # 依目前 self.index 取出這個會議底下所有代辦
    def get_current_todos(self):
        meeting = self.meetings[self.index]
        return meeting, list_todos_by_meeting(self.guild_id, meeting)

    # 把「目前會議」的代辦整理成要顯示的文字
    def build_content_text(self) -> str:
        meeting, rows = self.get_current_todos()

        header = (
            "📋 **本伺服器代辦清單（依會議分組）**\n\n"
            f"📌 會議：**{meeting}**　〔第 {self.index + 1} / {len(self.meetings)} 頁〕\n\n"
        )

        if not rows:
            body = "（此會議目前沒有代辦事項）"
        else:
            lines = []
            for row in rows:
                status = "✅" if row["done"] == 1 else ""
                prefix = f"{status} " if status else ""
                lines.append(
                    f"{prefix}**#{row['id']}**\n"
                    f"　內容：{row['content']}\n"
                    f"　截止：{row['deadline']}｜建立者：{row['created_by']}"
                )
            body = "\n\n".join(lines)

        return header + body

    # 依目前會議內容重新建立按鈕（上一個 / 下一個 / 刪除）
    def build_buttons(self):
        self.clear_items()

        # 上一個會議
        prev_btn = discord.ui.Button(
            label="⬅ 上一個會議",
            style=discord.ButtonStyle.secondary,
            disabled=(self.index == 0),
        )

        async def prev_callback(interaction: discord.Interaction):
            if interaction.user.id != self.user_id:
                return await interaction.response.send_message(
                    "你不能操作別人的代辦列表。", ephemeral=True
                )
            if self.index > 0:
                self.index -= 1
            self.build_buttons()
            await interaction.response.edit_message(
                content=self.build_content_text(),
                view=self,
            )

        prev_btn.callback = prev_callback
        self.add_item(prev_btn)

        # 下一個會議
        next_btn = discord.ui.Button(
            label="下一個會議 ➡",
            style=discord.ButtonStyle.secondary,
            disabled=(self.index >= len(self.meetings) - 1),
        )

        async def next_callback(interaction: discord.Interaction):
            if interaction.user.id != self.user_id:
                return await interaction.response.send_message(
                    "你不能操作別人的代辦列表。", ephemeral=True
                )
            if self.index < len(self.meetings) - 1:
                self.index += 1
            self.build_buttons()
            await interaction.response.edit_message(
                content=self.build_content_text(),
                view=self,
            )

        next_btn.callback = next_callback
        self.add_item(next_btn)

        # 目前會議底下的所有代辦 → 每一個代辦一個紅色「刪除」按鈕
        meeting, todos = self.get_current_todos()

        # Discord 一則訊息最多 25 個 component，這邊簡單限制一下
        max_delete_buttons = max(0, 25 - len(self.children))
        todos = todos[:max_delete_buttons]

        for row in todos:
            task_id = row["id"]
            label = f"刪除 #{task_id}"
            btn = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.danger,
            )

            async def del_callback(
                interaction: discord.Interaction,
                task_id=task_id,
            ):
                if interaction.user.id != self.user_id:
                    return await interaction.response.send_message(
                        "你不能操作別人的代辦列表。", ephemeral=True
                    )

                ok = delete_todo(self.guild_id, task_id)
                if not ok:
                    return await interaction.response.send_message(
                        "❌ 找不到這個代辦（可能已被刪除）", ephemeral=True
                    )

                # 刪完之後重新抓會議列表（有可能這個會議已經沒有代辦）
                self.meetings = list_meetings(self.guild_id)
                if not self.meetings:
                    # 這個伺服器所有代辦都刪光了
                    await interaction.response.edit_message(
                        content="📋 目前沒有任何代辦事項。",
                        view=None,
                    )
                    return

                if self.index >= len(self.meetings):
                    self.index = len(self.meetings) - 1

                self.build_buttons()
                await interaction.response.edit_message(
                    content=self.build_content_text(),
                    view=self,
                )

            btn.callback = del_callback
            self.add_item(btn)
























# ======================================================
#                     事件 & 指令
# ======================================================
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"已加入 {len(bot.guilds)} 個伺服器。")


@bot.command(name="join", aliases=["加入頻道"])
async def join(ctx):
    """讓 Bot 加入你所在的語音頻道"""
    if ctx.author.voice and ctx.author.voice.channel:
        channel = ctx.author.voice.channel
        if ctx.voice_client:
            await ctx.voice_client.move_to(channel)
        else:
            await channel.connect()
        await ctx.send(f"已加入語音頻道：{channel.name}")
    else:
        await ctx.send("❌ 你必須先進入語音頻道。")


@bot.command(name="leave", aliases=["離開頻道"])
async def leave(ctx):
    """讓 Bot 離開語音頻道"""
    vc = ctx.voice_client
    if vc:
        if ctx.guild.id in sink_dict:
            vc.stop_recording()
            del sink_dict[ctx.guild.id]
        await vc.disconnect()
        await ctx.send("👋 已離開語音頻道。")
    else:
        await ctx.send("我目前不在任何語音頻道內。")


@bot.command(name="record", aliases=["開始錄音"])
async def record(ctx):
    """開始錄製語音頻道中的聲音"""
    vc = ctx.voice_client
    if not vc:
        return await ctx.send("❌ 我不在語音頻道中，請先用 `!加入頻道`。")

    if ctx.guild.id in sink_dict:
        return await ctx.send("❌ 我已經在錄音了。")

    sink = discord.sinks.WaveSink()
    sink_dict[ctx.guild.id] = sink

    vc.start_recording(sink, finished_callback, ctx)
    await ctx.send("🎙 開始錄音！")


@bot.command(name="stop", aliases=["停止錄音"])
async def stop(ctx):
    """停止錄音並觸發 Whisper + Gemini 流程"""
    vc = ctx.voice_client
    if not vc or ctx.guild.id not in sink_dict:
        return await ctx.send("❌ 目前沒有在錄音。")

    vc.stop_recording()
    del sink_dict[ctx.guild.id]
    await ctx.send("⏹ 錄音停止，稍後會產生會議摘要…")




# bot.py

@bot.command(name="addtodo", aliases=["新增代辦"])
async def add_todo_cmd(ctx, *, args: str):
    """
    新增代辦事項
    用法：!新增代辦 會議名稱 | 任務內容 | 截止日期
    例：!新增代辦 BOT功能與優化討論 | 12/31前要完成BOT某功能優化 | 2025/12/31
    """
    parts = [p.strip() for p in args.split("|")]
    if len(parts) != 3:
        return await ctx.send("❌ 格式錯誤！請用：`!新增代辦 會議名稱 | 任務內容 | 截止日期`")

    meeting, content, deadline = parts
    guild_id = ctx.guild.id
    created_by = str(ctx.author)  # 例如 "wochan#1234"

    # 這裡會得到：任務編號 + 是否真的新增
    task_id, created = add_todo(guild_id, meeting, content, deadline, created_by)

    if created:
        # ✅ 真的新增成功
        await ctx.send(
            f"✅ 已新增代辦事項：\n"
            f"編號：`{task_id}`\n"
            f"會議：**{meeting}**\n"
            f"內容：{content}\n"
            f"截止日期：{deadline}\n"
            f"建立者：{ctx.author.mention}"
        )
    else:
        # ⚠️ DB 已經有一模一樣的未完成代辦
        await ctx.send(
            f"⚠️ 這個代辦事項已經存在，編號是 `#{task_id}`：\n"
            f"會議：**{meeting}**\n"
            f"內容：{content}\n"
            f"截止日期：{deadline}\n"
            f"（若要標記完成可以用 `!完成代辦 {task_id}`）"
        )






from collections import defaultdict

@bot.command(name="todolist", aliases=["代辦列表"])
async def list_todo_cmd(ctx):
    """一個會議一頁的代辦清單，可用按鈕切換會議與刪除代辦"""

    guild_id = ctx.guild.id
    meetings = list_meetings(guild_id)

    if not meetings:
        return await ctx.send("目前沒有任何代辦事項。可以用 `!新增代辦` 新增喔！")

    view = MeetingTodoView(guild_id=guild_id, user_id=ctx.author.id)
    content = view.build_content_text()

    await ctx.send(content, view=view)





@bot.command(name="donetodo", aliases=["完成代辦"])
async def done_todo_cmd(ctx, task_id: int):
    """
    標記某個代辦為完成 / 未完成
    用法：!完成代辦 任務編號
    例：!完成代辦 1
    """
    guild_id = ctx.guild.id
    updated = toggle_todo_done(guild_id, task_id)

    if not updated:
        return await ctx.send(f"找不到編號為 {task_id} 的代辦事項。請用 `!代辦列表` 查看編號。")

    status = "✅ 已標記為完成" if updated["done"] == 1 else "已改回未完成"

    await ctx.send(
        f"{status}：\n"
        f"**#{updated['id']}** 〔會議：{updated['meeting']}〕\n"
        f"內容：{updated['content']}\n"
        f"截止日期：{updated['deadline']}"
    )




@bot.command(name="deltodo", aliases=["刪除代辦"])
async def delete_todo_cmd(ctx, task_id: int):
    """
    刪除某個代辦事項
    用法：!刪除代辦 任務編號
    例：!刪除代辦 3
    """
    guild_id = ctx.guild.id
    ok = delete_todo(guild_id, task_id)

    if not ok:
        return await ctx.send(f"找不到編號為 {task_id} 的代辦事項。請用 `!代辦列表` 查看編號。")

    await ctx.send(f"🗑 已刪除代辦事項 `#{task_id}`。")





@bot.command(name="helpme", aliases=["指令"])
async def command_help(ctx):
    """顯示本 Bot 的指令教學"""
    help_text = """
📘 **即時語音會議 BOT 指令教學**

以下是目前可以使用的指令與說明：

────────────────────
🎧 **語音頻道操作**

• `!加入頻道` 或 `!join`  
　➡ 讓 Bot 加入你目前所在的語音頻道  
　　使用步驟：先進入某個語音頻道，再輸入這個指令

• `!離開頻道` 或 `!leave`  
　➡ 讓 Bot 離開語音頻道  
　　如果有在錄音，會先停止錄音再離開

────────────────────
🎙 **錄音與 AI 會議摘要**

• `!開始錄音` 或 `!record`  
　➡ 開始錄製目前語音頻道裡所有成員的聲音  
　　錄音期間可以自由發言，Bot 會幫你記錄下來

• `!停止錄音` 或 `!stop`  
　➡ 停止錄音，並自動進行：  
　　1. 語音轉文字（Whisper）  
　　2. 產生會議重點摘要（Gemini）  
　　完成後會在文字頻道貼出整理好的會議總結  

────────────────────
📝 **代辦事項管理（寫入資料庫，不會因為重開 Bot 消失）**

• `!新增代辦 會議名稱 | 任務內容 | 截止日期`  
　➡ 新增一筆代辦事項  
　　範例：  
　　`!新增代辦 BOT功能與優化討論 | 12/31前要完成BOT某功能優化 | 2025/12/31`

• `!代辦列表` 或 `!todolist`  
　➡ 顯示「本伺服器」目前所有代辦事項  
　　每一筆會顯示：編號、會議名稱、內容、截止日期、建立者、狀態（⭕/✅）

• `!完成代辦 任務編號` 或 `!donetodo 任務編號`  
　➡ 切換某一筆代辦的完成狀態  
　　範例：  
　　`!完成代辦 1`（會在 ⭕ / ✅ 之間切換）

────────────────────
✅ **建議使用流程**

1️⃣ 先進入語音頻道  
2️⃣ 輸入 `!加入頻道`  
3️⃣ 輸入 `!開始錄音` 開始會議  
4️⃣ 會議結束後輸入 `!停止錄音`  
5️⃣ 查看 Bot 送出的「AI 會議總結」  
6️⃣ 針對重要工作，使用 `!新增代辦` 建立追蹤任務  
7️⃣ 之後用 `!代辦列表` / `!完成代辦` 管理進度
"""
    await ctx.send(help_text)




# ======================================================
#                     啟動 Bot
# ======================================================
if not BOT_TOKEN:
    print("錯誤：請在 .env 設定 BOT_TOKEN")
else:
    init_db()  # 啟動 BOT 前先確保資料表已建立
    bot.run(BOT_TOKEN)
