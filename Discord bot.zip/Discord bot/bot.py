import discord
from discord.ext import commands
import os
from dotenv import load_dotenv
from faster_whisper import WhisperModel
import google.generativeai as genai
import asyncio
from concurrent.futures import ThreadPoolExecutor

# ======================================================
#                   基本設定
# ======================================================
load_dotenv()
TOKEN = os.getenv('BOT_TOKEN')

if TOKEN is None:
    print("錯誤：請設定環境變數 BOT_TOKEN")
    exit()

# 建立 Intents 物件，決定 Bot 可以使用哪些事件
intents = discord.Intents.default()

# 開啟讀取文字訊息內容的權限（例如 read 使用者打的 !指令）
intents.message_content = True

# 開啟語音狀態事件（誰加入 / 離開語音頻道、錄音需要用到）
intents.voice_states = True

#開啟伺服器 / Guild 相關事件（取得伺服器清單、成員、頻道等）
intents.guilds = True

#設定指令前綴詞
bot = commands.Bot(command_prefix='!', intents=intents)

#儲存WAV音檔的容器
sink_dict = {}

# Whisper GPU 模型
model = WhisperModel("large-v3-turbo", device="cuda", compute_type="float16")

# GPU 並行運算池（可根據 GPU 大小調整）
executor = ThreadPoolExecutor(max_workers=6)

# Gemini 設定
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))


def get_gemini_model():
    try:
        return genai.GenerativeModel("models/gemini-2.5-flash")
    except:
        return genai.GenerativeModel("models/gemini-2.5-pro")
    



# ======================================================
#                   Whisper 並行轉錄
# ======================================================
# 建立一個「非同步版本」的語音轉文字函式
# 傳入：音檔路徑 path
# 回傳：Whisper 的 (segments, info) 結果
async def transcribe_async(path): 
    """非同步包裝 Whisper 推論（讓 GPU 可以配合 asyncio 使用）"""

    # 取得目前這個 async context 底下的事件迴圈（Event Loop）
    loop = asyncio.get_event_loop()

    # 在「執行緒池 executor」裡面執行一個同步的工作（model.transcribe），
    # 不要卡住整個 async Bot；await 會等結果跑完再回傳。
    return await loop.run_in_executor(
        executor,              # 指定用哪個 ThreadPoolExecutor 來跑
        lambda: model.transcribe(  # 要丟進 thread 執行的實際工作（用 lambda 包起來）
            path,                  # 要辨識的音檔路徑
            language="zh",         # 指定語言為中文，提升辨識準確度
            beam_size=5,           # Beam search 寬度，越大越準但越慢
            vad_filter=True        # 啟用語音活動檢測（Voice Activity Detection），過濾靜音與雜訊
        )
    )


# ======================================================
#         Discord 錄音完成後會自動呼叫的 callback
# ======================================================
async def finished_callback(sink, ctx):

    # ------------------------------------------------------
    # Step 1: 沒錄到任何東西會提醒
    # ------------------------------------------------------
    if not sink.audio_data:
        await ctx.send("❌ 沒有錄到任何聲音。")
        return

    os.makedirs("recordings", exist_ok=True)

    audio_paths = {}   # user_id → file_path
    usernames = {}     # user_id → name

    # ------------------------------------------------------
    # Step 2: 儲存每個使用者的音檔
    # ------------------------------------------------------
    for user_id, audio in sink.audio_data.items():
        user = ctx.guild.get_member(user_id)
        username = user.name if user else f"user_{user_id}"

        filepath = f"recordings/{ctx.guild.id}_{user_id}.wav"
        with open(filepath, "wb") as f:
            f.write(audio.file.getvalue())

        audio_paths[user_id] = filepath
        usernames[user_id] = username

    await ctx.send(f"🎧 偵測到 {len(audio_paths)} 份語音，正在使用 GPU 並行辨識…")

    # ------------------------------------------------------
    # Step 3: GPU 並行跑所有音檔
    # ------------------------------------------------------
    tasks = [transcribe_async(p) for p in audio_paths.values()]
    results = await asyncio.gather(*tasks)

    transcripts = {}
    user_ids = list(audio_paths.keys())

    # ------------------------------------------------------
    # Step 4: 整理結果（自動對應到使用者）
    # ------------------------------------------------------
    for i, (segments, info) in enumerate(results):
        user_id = user_ids[i]
        username = usernames[user_id]

        text = " ".join(seg.text for seg in segments).strip()
        if not text:
            text = "(無語音內容)"

        transcripts[username] = text

        # 刪音檔
        try:
            os.remove(audio_paths[user_id])
        except:
            pass

    # ------------------------------------------------------
    # Step 5: 組成一段文字 → 給 Gemini 做摘要
    # ------------------------------------------------------
    block = "\n\n".join([f"【{u}】\n{t}" for u, t in transcripts.items()])

    prompt = f"""
你是一個會從語音辨識內容中整理會議摘要的助理。
辨識內容可能有錯字，請使用語意理解。

請你輸出：

1️⃣ 會議整體主題  
2️⃣ 會議重點摘要（3～8 點）  
3️⃣ 若有結論、共識或待辦事項請列出  

以下是所有使用者的語音內容：
---
{block}
"""

    await ctx.send("📝 Whisper 完成，正在使用 Gemini 整理摘要…")

    # ------------------------------------------------------
    # Step 6: Gemini 非同步運行，避免阻塞 Bot
    # ------------------------------------------------------
    try:
        gemini = get_gemini_model()
        summary = await asyncio.to_thread(gemini.generate_content, prompt)
        summary_text = summary.text.strip()
    except Exception as e:
        summary_text = f"❌ Gemini 整理失敗：{e}"

    # ------------------------------------------------------
    # Step 7: 最終輸出
    # ------------------------------------------------------
    await ctx.send(f"💡 **AI 會議總結**：\n{summary_text}")
    await ctx.send("✅ 全部完成！")


# ======================================================
#                  Discord 指令區
# ======================================================
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}  (ID: {bot.user.id})")
    print(f"加入 {len(bot.guilds)} 個伺服器")


@bot.command(name="join", aliases=["加入頻道"])
async def join(ctx):
    if ctx.author.voice and ctx.author.voice.channel:
        channel = ctx.author.voice.channel
        if ctx.voice_client:
            await ctx.voice_client.move_to(channel)
        else:
            await channel.connect()
        await ctx.send(f"已加入語音頻道：{channel.name}")
    else:
        await ctx.send("❌ 你必須先進入語音頻道。")


@bot.command(name="leave", aliases=["離開頻道"])
async def leave(ctx):
    vc = ctx.voice_client
    if vc:
        if ctx.guild.id in sink_dict:
            vc.stop_recording()
            del sink_dict[ctx.guild.id]
        await vc.disconnect()
        await ctx.send("👋 已離開語音頻道")
    else:
        await ctx.send("我目前沒有在語音頻道內。")


@bot.command(name="record", aliases=["開始錄音"])
async def record(ctx):
    vc = ctx.voice_client
    if not vc:
        return await ctx.send("❌ 我不在語音頻道中，請先用 `!join`。")

    if ctx.guild.id in sink_dict:
        return await ctx.send("❌ 我已經在錄音了。")

    sink = discord.sinks.WaveSink()
    sink_dict[ctx.guild.id] = sink

    vc.start_recording(sink, finished_callback, ctx)
    await ctx.send("🎙 開始錄音！")


@bot.command(name="stop", aliases=["停止錄音"])
async def stop(ctx):
    vc = ctx.voice_client
    if not vc or ctx.guild.id not in sink_dict:
        return await ctx.send("❌ 目前沒有在錄音。")

    vc.stop_recording()
    del sink_dict[ctx.guild.id]
    await ctx.send("⏹ 錄音停止，處理中…")


# ======================================================
bot.run(TOKEN)
